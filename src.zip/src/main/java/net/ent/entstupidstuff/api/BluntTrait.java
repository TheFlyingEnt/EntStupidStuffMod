package net.ent.entstupidstuff.api;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;


//TODO: Add Blunt Attributes

public class BluntTrait {

    /*public static boolean isWeaponBlunt(PlayerEntity player) {
        return !player.getOffHandStack().isEmpty();
    }*/

    public static void applyBluntEffect(LivingEntity target) {
        target.addStatusEffect(new StatusEffectInstance(StatusEffects.MINING_FATIGUE, 20, 4));
    }

}
