package net.ent.entstupidstuff.item.itemType;

import java.util.List;

import net.ent.entstupidstuff.EntStupidStuff;
import net.ent.entstupidstuff.api.CircleSlashTrait;
import net.ent.entstupidstuff.api.TwoHandTrait;
import net.minecraft.component.type.AttributeModifierSlot;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;



public class LongSwordItem extends SwordItem {

    ToolMaterial current;

    //Code Clean-Up
    public LongSwordItem(ToolMaterial toolMaterial, Settings settings) {
        super(toolMaterial, settings);
        current = toolMaterial;
    }

    // Default Variable to Handle Sword Properties
    static double baseAttackDamageD = 3.5;
    static double attackSpeedD = -2.6f;
    static int toolReachD = 1;


    public static final Identifier ATTK_BMOD_ID = EntStupidStuff.id("double_handed_bonus");

    // For 1.20.5+ Adding TwoHanded ToolTip
    @Override
    public void appendTooltip(ItemStack itemStack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.translatable("item.entstupidstuff.double_hand.tooltip"));
    }

    /*@Override
    public void inventoryTick(ItemStack stack, World world, Entity entity, int slot, boolean selected) {
        if (!world.isClient && entity instanceof PlayerEntity) {
            PlayerEntity player = (PlayerEntity) entity;
            if (TwoHandTrait.isUsingTwoHands(player) && player.getMainHandStack().getItem() == this) {          
                TwoHandTrait.applyMiningFatigue(player); 
            }

            if (TwoHandTrait.isUsingTwoHands(player) && player.getMainHandStack().getItem() == this) {
                if (!player.getOffHandStack().isEmpty()) {
                    TwoHandTrait.applyDamageReduction(player, true, baseAttackDamageD + this.getMaterial().getAttackDamage());
                } /*else {
                    TwoHandTrait.applyDamageReduction(player, false, baseAttackDamageD + this.getMaterial().getAttackDamage());
                }
            }


        }
    }*/ // Last Update

    public void inventoryTick(ItemStack stack, World world, Entity entity, int slot, boolean selected) {
        if (!world.isClient && entity instanceof PlayerEntity) {
            PlayerEntity player = (PlayerEntity) entity;
            boolean isHoldingTwoHandedWeapon = player.getMainHandStack().getItem() instanceof LongSwordItem;

            if (isHoldingTwoHandedWeapon) {
                boolean reduceDamage = TwoHandTrait.isUsingTwoHands(player);
                double toolDamage = baseAttackDamageD + this.getMaterial().getAttackDamage(); // Adjust this to get your tool's damage value
                TwoHandTrait.applyDamageReduction(player, reduceDamage, toolDamage);
                if (reduceDamage) {
                    TwoHandTrait.applyMiningFatigue(player);
                }
            } else {
                // Ensure the damage reduction is removed if the player is not holding the weapon
                TwoHandTrait.applyDamageReduction(player, false, 0);
            }
        }
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        if (!world.isClient && hand == Hand.MAIN_HAND) {
            CircleSlashTrait.performCircleSlash(player, 2.0); // Perform the circle slash with a 2-block radius
            return new TypedActionResult<>(ActionResult.SUCCESS, player.getStackInHand(hand));
        }
        return new TypedActionResult<>(ActionResult.PASS, player.getStackInHand(hand));
    }



    // Only Give 75% Damage is TwoHanded = false
    /*@Override
    public void inventoryTick(ItemStack stack, World world, Entity entity, int slot, boolean selected) {
        if (!world.isClient && entity instanceof PlayerEntity) {
            PlayerEntity player = (PlayerEntity) entity;
            if (player.getMainHandStack().getItem() == this) {
                if (!player.getOffHandStack().isEmpty()) {
                    applyDamageReduction(player, true);
                } else {
                    applyDamageReduction(player, false);
                }
            }
        }
    }*/

    //public static final Identifier ATTK_D = EntStupidStuff.id("dmane_red");

    /*private void applyDamageReduction(PlayerEntity player, boolean reduceDamage) {
        double damageMultiplier = reduceDamage ? 0.25 : 1.0;
        EntityAttributeInstance attackDamageInstance = player.getAttributeInstance(EntityAttributes.GENERIC_ATTACK_DAMAGE);

        // Remove the existing modifier if it exists
        if (attackDamageInstance != null) {
            attackDamageInstance.removeModifier(BASE_ATTACK_DAMAGE_MODIFIER_ID);
            attackDamageInstance.addTemporaryModifier(new EntityAttributeModifier(
                BASE_ATTACK_DAMAGE_MODIFIER_ID,  
                8.5 * (damageMultiplier), 
                EntityAttributeModifier.Operation.ADD_VALUE)
            );
        }
    }*/

    //Adding TwoHanded ToolTip
    public static final Identifier BASE_ATTACK_RANGE_MODIFIER_ID = EntStupidStuff.id("base_attack_reach");

    //Note: Because the SwordItem.class Cant not be override because it is static, we are forced to recreate it.
    public static AttributeModifiersComponent createAttributeModifiers(ToolMaterial material, double baseAttackDamage, double attackSpeed, int toolReach) {
		return AttributeModifiersComponent.builder()
			.add(
				EntityAttributes.GENERIC_ATTACK_DAMAGE,
				new EntityAttributeModifier(
					BASE_ATTACK_DAMAGE_MODIFIER_ID, (double)((float)baseAttackDamage + material.getAttackDamage()), EntityAttributeModifier.Operation.ADD_VALUE
				),
				AttributeModifierSlot.MAINHAND
			)
			.add(
				EntityAttributes.GENERIC_ATTACK_SPEED,
				new EntityAttributeModifier(BASE_ATTACK_SPEED_MODIFIER_ID, (double)attackSpeed, EntityAttributeModifier.Operation.ADD_VALUE),
				AttributeModifierSlot.MAINHAND
			)
            .add(EntityAttributes.PLAYER_ENTITY_INTERACTION_RANGE,
                new EntityAttributeModifier(BASE_ATTACK_RANGE_MODIFIER_ID, toolReach, EntityAttributeModifier.Operation.ADD_VALUE),
                AttributeModifierSlot.MAINHAND
            ) 
            //TODO: PLAYER_SWEEPING_DAMAGE_RATIO 
			.build();    
	}

    public static AttributeModifiersComponent createAttributeModifiers(ToolMaterial material) {
		return AttributeModifiersComponent.builder()
			.add(
				EntityAttributes.GENERIC_ATTACK_DAMAGE,
				new EntityAttributeModifier(
					BASE_ATTACK_DAMAGE_MODIFIER_ID, (double)((float)baseAttackDamageD + material.getAttackDamage()), EntityAttributeModifier.Operation.ADD_VALUE
				),
				AttributeModifierSlot.MAINHAND
			)
			.add(
				EntityAttributes.GENERIC_ATTACK_SPEED,
				new EntityAttributeModifier(BASE_ATTACK_SPEED_MODIFIER_ID, (double)attackSpeedD, EntityAttributeModifier.Operation.ADD_VALUE),
				AttributeModifierSlot.MAINHAND
			)
            .add(EntityAttributes.PLAYER_ENTITY_INTERACTION_RANGE,
                new EntityAttributeModifier(BASE_ATTACK_RANGE_MODIFIER_ID, toolReachD, EntityAttributeModifier.Operation.ADD_VALUE),
                AttributeModifierSlot.MAINHAND
            ) 
            //TODO: PLAYER_SWEEPING_DAMAGE_RATIO 
			.build();    
	}

    //Legacy Code





    /*@Override
    public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        if (attacker instanceof PlayerEntity) {
            PlayerEntity player = (PlayerEntity) attacker;
            if (TwoHandTrait.isUsingTwoHands(player)) {
                TwoHandTrait.applyMiningFatigue(player);
            }
        }
        return super.postHit(stack, target, attacker);
    }*/

}
