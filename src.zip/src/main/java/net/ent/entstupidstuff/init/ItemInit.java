package net.ent.entstupidstuff.init;

import java.util.LinkedHashMap;
import java.util.Map;

import net.ent.entstupidstuff.item.itemType.LongSwordItem;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;

import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ToolMaterials;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * This Class is for Item Registration
 */

public class ItemInit {

    // Code Cleanup

    // Var ArrayList/List Map Containing All Items
    public static final Map<Identifier, Item> ItemList = new LinkedHashMap<>();

    //Creating Var ITEM_GROUP which will Contain all Vanilla Weapon Types:
    public static final RegistryKey<ItemGroup> ENTSTUPIDSTUFF_COMBAT_GROUP = RegistryKey.of(RegistryKeys.ITEM_GROUP, Identifier.of("entstupidstuff", "combat_group"));


    /*
     *  Creating Items: Long Swords
    */

    float LS_ASpeed = 4;       //Attack Speed
    int LS_ADamage = 4;         //Attack Damange (Default)
    float LS_AReach = 0.8f;    //Attack Range
    float LS_AdditionalModifier = 0.5f; // Additional modifier to simulate 0.5 extra damage

    /**
     * Data Banks:
     * -----------------
     * Netherite Bonus = 5
     * Diamond Bonus = 4?
     * Iron Bonus = 3?
     * Stone Bonus = 2?
     * Wood Bonus = 1?
     * 
     * 
     * Long Swords add:
     * - (3.5 Damage + Bonus) So 13.5 - 8.5 = 5 + 3.5 = 8.5
     * - Attack Speed 
     *   - Default is 4 is Attack Speed
     *   - Need 1.4f so (4-1.4) = -2.6
     * 
     * 
     * is 1.4f and toolReach is 1
     * 
     */

     /*
      *
      * Two Hand Item Weapons Enchant:
      * GreatSword - Guarding I, II and III - Negs Damage
      *
      */


    public static final LongSwordItem WOOD_LONG_SWORD_ITEM = registerItems("wooden_long_sword",
        new LongSwordItem(ToolMaterials.WOOD,
            new Item.Settings()
            .attributeModifiers(LongSwordItem
            .createAttributeModifiers(ToolMaterials.WOOD, 3.5, -2.6f, 1)) //(Material, ADamage, ASpeed)
        )
    );

    public static final LongSwordItem STONE_LONG_SWORD_ITEM = registerItems("stone_long_sword",
        new LongSwordItem(ToolMaterials.STONE,
            new Item.Settings()
            .attributeModifiers(LongSwordItem
            .createAttributeModifiers(ToolMaterials.STONE, 3.5, -2.6f, 1)) //(Material, ADamage, ASpeed)
        )
    );

    public static final LongSwordItem IRON_LONG_SWORD_ITEM = registerItems("iron_long_sword",
        new LongSwordItem(ToolMaterials.IRON, new Item.Settings().attributeModifiers(LongSwordItem.createAttributeModifiers(ToolMaterials.IRON)))
    );

    public static final LongSwordItem DIAMOND_LONG_SWORD_ITEM = registerItems("diamond_long_sword",
        new LongSwordItem(ToolMaterials.DIAMOND, new Item.Settings().attributeModifiers(LongSwordItem.createAttributeModifiers(ToolMaterials.DIAMOND)))
    );

    public static final LongSwordItem NETHERITE_LONG_SWORD_ITEM = registerItems("netherite_long_sword",
        new LongSwordItem(ToolMaterials.NETHERITE, new Item.Settings().attributeModifiers(LongSwordItem.createAttributeModifiers(ToolMaterials.NETHERITE)))
    );





















        /*.with(EntityAttributes.PLAYER_ENTITY_INTERACTION_RANGE,
        new EntityAttributeModifier(LongSwordItem.ATTK_BMOD_ID, 1.0F, EntityAttributeModifier.Operation.ADD_VALUE), AttributeModifierSlot.MAINHAND)*/
        /*.with(EntityAttributes.GENERIC_ATTACK_DAMAGE,
        new EntityAttributeModifier(LongSwordItem.ATTK_BMOD_ID, 0.5, EntityAttributeModifier.Operation.ADD_VALUE), AttributeModifierSlot.MAINHAND)*/






 
   
    
    public static <I extends Item> I registerItems(String name, I item) {
        ItemList.put(Identifier.of("entstupidstuff", name), item);
        return item;

    }


    public static void onInitialize() {

        //Registering: Combat Tab (Item Group)
        Registry.register(Registries.ITEM_GROUP, ENTSTUPIDSTUFF_COMBAT_GROUP, FabricItemGroup.builder()
        .icon(() -> new ItemStack(WOOD_LONG_SWORD_ITEM))
        .displayName(Text.translatable("item.entstupidstuff.item_group"))
        .build());

        //Registering: Combat Items
        for (Identifier id : ItemList.keySet()) {
            Registry.register(Registries.ITEM, id, ItemList.get(id));
            ItemGroupEvents.modifyEntriesEvent(ENTSTUPIDSTUFF_COMBAT_GROUP).register(entries -> entries.add(ItemList.get(id)));
        }

    }
}
