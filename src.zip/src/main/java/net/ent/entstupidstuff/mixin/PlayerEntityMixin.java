package net.ent.entstupidstuff.mixin;

//import net.ent.entstupidstuff.item.itemType.LongSwordItem;
import net.minecraft.entity.player.PlayerEntity;
//import net.minecraft.item.ItemStack;
//import net.minecraft.item.Items;
//import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
//import org.spongepowered.asm.mixin.injection.At;
//import org.spongepowered.asm.mixin.injection.Inject;
//import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerEntity.class)
public abstract class PlayerEntityMixin {

    /*@Inject(method = "getAttackReachScale", at = @At("HEAD"), cancellable = true)
    public void getAttackReachScale(CallbackInfoReturnable<Float> cir) {
        PlayerEntity player = (PlayerEntity) (Object) this;
        ItemStack mainHandItem = player.getMainHandStack();

        if (mainHandItem.getItem() instanceof LongSwordItem) {
            cir.setReturnValue(1.5F);  // Increase reach by 50%
        }
    }*/
}
