package net.ent.entstupidstuff.registry;

import net.ent.entstupidstuff.EntStupidStuff;
import net.ent.entstupidstuff.entity.PiglinFungalEntity;
import net.ent.entstupidstuff.entity.PiglinWarriorEntity;
import net.ent.entstupidstuff.entity.ArmoredPillagerEntity;
import net.ent.entstupidstuff.entity.LobberZombieEntity;
import net.ent.entstupidstuff.entity.RSGolemEntity;
import net.ent.entstupidstuff.entity.ScorchedZombieEntity;
import net.ent.entstupidstuff.entity.SoulSkeletonEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class EntityFactory {

    public static final EntityType<LobberZombieEntity> LOBBER_ZOMBIE = Registry.register(Registries.ENTITY_TYPE,
        Identifier.of(EntStupidStuff.MOD_ID, "lobber_zombie"),
        EntityType.Builder.create(LobberZombieEntity::new, SpawnGroup.MONSTER)
        .dimensions(0.6F, 1.95F)
		.eyeHeight(1.74F)
		.passengerAttachments(2.0125F)
		.vehicleAttachment(-0.7F)
		.maxTrackingRange(8)
        .build()
    );

    public static final EntityType<ScorchedZombieEntity> ZOMBIE_SCORCHED = Registry.register(Registries.ENTITY_TYPE,
        Identifier.of(EntStupidStuff.MOD_ID, "zombie_scorched"),
        EntityType.Builder.create(ScorchedZombieEntity::new, SpawnGroup.MONSTER)
        .dimensions(0.6F, 1.95F)
		.eyeHeight(1.74F)
		.passengerAttachments(2.0125F)
		.vehicleAttachment(-0.7F)
		.maxTrackingRange(8)
        .build()
    );

    public static final EntityType<ArmoredPillagerEntity> ARMORED_PILLAGER = Registry.register(Registries.ENTITY_TYPE,
        Identifier.of(EntStupidStuff.MOD_ID, "armored_pillager"),
        EntityType.Builder.create(ArmoredPillagerEntity::new, SpawnGroup.MONSTER)
        .spawnableFarFromPlayer()
		.dimensions(0.6F, 1.95F)
		.passengerAttachments(2.0F)
		.vehicleAttachment(-0.6F)
		.maxTrackingRange(8)
        .build()
    );

    public static final EntityType<SoulSkeletonEntity> SOUL_SKELETON = Registry.register(Registries.ENTITY_TYPE,
        Identifier.of(EntStupidStuff.MOD_ID, "soul_skeleton"),
        EntityType.Builder.create(SoulSkeletonEntity::new, SpawnGroup.MONSTER)
        .dimensions(0.6F, 1.99F)
        .eyeHeight(1.74F)
        .vehicleAttachment(-0.7F)
        .maxTrackingRange(8)
        .build()
    );

    public static final EntityType<RSGolemEntity> RSGolem = Registry.register(Registries.ENTITY_TYPE,
        Identifier.of(EntStupidStuff.MOD_ID, "redstone_golem"),
        EntityType.Builder.create(RSGolemEntity::new, SpawnGroup.MONSTER)
        .dimensions(2.0f, 3.5F)
        .eyeHeight(2.60F)
        .vehicleAttachment(-0.7F)
        .maxTrackingRange(8)
        .build()
    );

    /*
    *       The Fire of the Hunt Update
    */
    // Adds Piglin Warior, Hovering Inferno, Fox Hound, Piglin Guard
    // Soul Skeleton, Wisps, Skeleton Wolves and Ghoals

    // Wither Bones, Hunt Armor Trim, Golden Armor Trim, Blaze Rod Trim Material

    public static final EntityType<PiglinWarriorEntity> PIGLIN_WARRIOR = Registry.register(Registries.ENTITY_TYPE,
        Identifier.of(EntStupidStuff.MOD_ID, "piglin_warrior"),
        EntityType.Builder.create(PiglinWarriorEntity::new, SpawnGroup.MONSTER)
        .dimensions(0.6F, 1.95F)
        .eyeHeight(1.79F)
        .passengerAttachments(2.0125F)
        .vehicleAttachment(-0.7F)
        .maxTrackingRange(8)
        .build()
    );

    public static final EntityType<PiglinFungalEntity> PIGLIN_FUNGAL = Registry.register(Registries.ENTITY_TYPE,
        Identifier.of(EntStupidStuff.MOD_ID, "piglin_fungal"),
        EntityType.Builder.create(PiglinFungalEntity::new, SpawnGroup.MONSTER)
        .dimensions(0.6F, 1.95F)
        .eyeHeight(1.79F)
        .passengerAttachments(2.0125F)
        .vehicleAttachment(-0.7F)
        .maxTrackingRange(8)
    .build()
);






    public static void onInitialize() {
        
        FabricDefaultAttributeRegistry.register(LOBBER_ZOMBIE, LobberZombieEntity.createLobberZombieAttributes());
        FabricDefaultAttributeRegistry.register(ZOMBIE_SCORCHED, ScorchedZombieEntity.createScorchedZombieAttributes());
        FabricDefaultAttributeRegistry.register(ARMORED_PILLAGER, ArmoredPillagerEntity.createArmoredPillagerAttributes/*createPillagerAttributes*/());
        FabricDefaultAttributeRegistry.register(SOUL_SKELETON, SoulSkeletonEntity.createSoulSkeletonAttributes/*createPillagerAttributes*/());
        FabricDefaultAttributeRegistry.register(RSGolem, RSGolemEntity.createVindicatorAttributes()/*createPillagerAttributes*/);

        //The Fire of the Hunt Update
        FabricDefaultAttributeRegistry.register(PIGLIN_WARRIOR, PiglinWarriorEntity.createPiglinBruteAttributes());
        FabricDefaultAttributeRegistry.register(PIGLIN_FUNGAL, PiglinFungalEntity.createPiglinAttributes());
       
        


    }
}
