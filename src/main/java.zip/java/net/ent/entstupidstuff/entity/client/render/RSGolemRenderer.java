package net.ent.entstupidstuff.entity.client.render;

import net.ent.entstupidstuff.EntStupidStuff;
import net.ent.entstupidstuff.entity.ModModelLayers;
import net.ent.entstupidstuff.entity.RSGolemEntity;
import net.ent.entstupidstuff.entity.client.model.RSGolemModel;
import net.minecraft.client.render.entity.EntityRendererFactory.Context;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.util.Identifier;

public class RSGolemRenderer extends MobEntityRenderer<RSGolemEntity, RSGolemModel<RSGolemEntity>>{

    public RSGolemRenderer(Context context) {
        super(context, new RSGolemModel<>(context.getPart(ModModelLayers.RSGolem)), 1.1F);
    }

    private static final Identifier TEXTURE = Identifier.of(EntStupidStuff.MOD_ID,"textures/entity/redstone_golem.png");

    @Override
    public Identifier getTexture(RSGolemEntity entity) {
        return TEXTURE;
    }




}
