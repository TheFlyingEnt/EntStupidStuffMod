package net.ent.entstupidstuff.entity;

import net.ent.entstupidstuff.entity.client.model.LobberModel;
import net.ent.entstupidstuff.entity.client.model.RSGolemModel;
import net.ent.entstupidstuff.entity.client.model.ScorchedModel;
import net.ent.entstupidstuff.entity.client.render.PiglinExtraRenderer;
import net.ent.entstupidstuff.entity.client.render.ArmoredPillagerEntityRenderer;
import net.ent.entstupidstuff.entity.client.render.LobberEntityRenderer;
import net.ent.entstupidstuff.entity.client.render.RSGolemRenderer;
import net.ent.entstupidstuff.entity.client.render.ScorchedEntityRenderer;
import net.ent.entstupidstuff.entity.client.render.SoulSkeletonEntityRender;
import net.ent.entstupidstuff.registry.EntityFactory;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.util.Identifier;

public class ModModelLayers {

    public static final EntityModelLayer LOBBER_ZOMBIE =
    new EntityModelLayer(Identifier.of("entstupidstuff", "lobber_zombie"), "main");

    public static final EntityModelLayer ZOMBIE_SCORCHED =
    new EntityModelLayer(Identifier.of("entstupidstuff", "zombie_scorched"), "main");

    public static final EntityModelLayer ZOMBIE_DEEPCRAWLE =
    new EntityModelLayer(Identifier.of("entstupidstuff", "zombie_deepcrawle"), "main");

    public static final EntityModelLayer ZOMBIE_ROTSPAWN =
    new EntityModelLayer(Identifier.of("entstupidstuff", "zombie_rotspawn"), "main");

    public static final EntityModelLayer PILLAGER_ARMORED =
    new EntityModelLayer(Identifier.of("entstupidstuff", "pillager_armored"), "main");

    public static final EntityModelLayer RSGolem =
    new EntityModelLayer(Identifier.of("entstupidstuff", "redstone_golem"), "main");

    // Fires of the Hunt Update:

    public static final EntityModelLayer PIGLIN_WARRIOR =
    new EntityModelLayer(Identifier.of("entstupidstuff", "piglin_warrior"), "main");



    public static void onInitialize() {
        
        EntityRendererRegistry.register(EntityFactory.LOBBER_ZOMBIE, (EntityRendererFactory.Context context) -> new LobberEntityRenderer(context));
        EntityRendererRegistry.register(EntityFactory.LOBBER_ZOMBIE, (EntityRendererFactory.Context context) -> new LobberEntityRenderer(context, ModModelLayers.LOBBER_ZOMBIE, EntityModelLayers.ZOMBIE_INNER_ARMOR, EntityModelLayers.ZOMBIE_OUTER_ARMOR));
        EntityModelLayerRegistry.registerModelLayer(ModModelLayers.LOBBER_ZOMBIE, LobberModel::getTexturedModelData);

        EntityRendererRegistry.register(EntityFactory.ZOMBIE_SCORCHED, (EntityRendererFactory.Context context) -> new ScorchedEntityRenderer(context));
        EntityRendererRegistry.register(EntityFactory.ZOMBIE_SCORCHED, (EntityRendererFactory.Context context) -> new ScorchedEntityRenderer(context, ModModelLayers.ZOMBIE_SCORCHED, EntityModelLayers.ZOMBIE_INNER_ARMOR, EntityModelLayers.ZOMBIE_OUTER_ARMOR));
        EntityModelLayerRegistry.registerModelLayer(ModModelLayers.ZOMBIE_SCORCHED, ScorchedModel::getTexturedModelData);

        //EntityRendererRegistry.register(EntityFactory.ARMORED_PILLAGER, (EntityRendererFactory.Context context) -> new ArmoredPillagerEntityRenderer(context));
        //EntityModelLayerRegistry.registerModelLayer(ModModelLayers.PILLAGER_ARMORED, ScorchedModel::getTexturedModelData);

        EntityRendererRegistry.register(EntityFactory.ARMORED_PILLAGER, (EntityRendererFactory.Context context) -> new ArmoredPillagerEntityRenderer(context));
        
        EntityRendererRegistry.register(EntityFactory.SOUL_SKELETON, (EntityRendererFactory.Context context) -> new SoulSkeletonEntityRender(context));
        EntityRendererRegistry.register(EntityFactory.SOUL_SKELETON, (EntityRendererFactory.Context context) -> new SoulSkeletonEntityRender(context, EntityModelLayers.SKELETON, EntityModelLayers.SKELETON_INNER_ARMOR, EntityModelLayers.SKELETON_OUTER_ARMOR));

        EntityRendererRegistry.register(EntityFactory.RSGolem, (EntityRendererFactory.Context context) -> new RSGolemRenderer(context));
        EntityModelLayerRegistry.registerModelLayer(ModModelLayers.RSGolem, RSGolemModel::getTexturedModelData);

        //The Fire of the Hunt Update
        EntityRendererRegistry.register(EntityFactory.PIGLIN_WARRIOR, (EntityRendererFactory.Context context) -> new PiglinExtraRenderer(context, EntityModelLayers.PIGLIN_BRUTE, EntityModelLayers.PIGLIN_BRUTE_INNER_ARMOR, EntityModelLayers.PIGLIN_BRUTE_OUTER_ARMOR, false));
        EntityRendererRegistry.register(EntityFactory.PIGLIN_FUNGAL, (EntityRendererFactory.Context context) -> new PiglinExtraRenderer(context, EntityModelLayers.PIGLIN_BRUTE, EntityModelLayers.PIGLIN_BRUTE_INNER_ARMOR, EntityModelLayers.PIGLIN_BRUTE_OUTER_ARMOR, false));

    }

    /*public static TexturedModelData getPiglinTexturedModelData(){
        return TexturedModelData.of(PiglinEntityModel.getModelData(Dilation.NONE), 64, 64);
    }*/


}
