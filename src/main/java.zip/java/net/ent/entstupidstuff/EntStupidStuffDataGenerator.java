package net.ent.entstupidstuff;

import net.ent.entstupidstuff.datagen.BlockTagProvider;
import net.ent.entstupidstuff.datagen.ItemTagProvider;
import net.ent.entstupidstuff.datagen.ModEnchantmentProvider;
import net.ent.entstupidstuff.datagen.ModLangProvider;
import net.ent.entstupidstuff.datagen.ModLootTableProvider;
//import net.ent.entstupidstuff.datagen.ModRecipeProvider;
import net.ent.entstupidstuff.datagen.ModRecipeProvider;
import net.ent.entstupidstuff.datagen.ModelProvider;
import net.fabricmc.fabric.api.datagen.v1.DataGeneratorEntrypoint;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;

public class EntStupidStuffDataGenerator implements DataGeneratorEntrypoint {
	
	@Override
	public void onInitializeDataGenerator(FabricDataGenerator fabricDataGenerator) {
		FabricDataGenerator.Pack pack = fabricDataGenerator.createPack();

		pack.addProvider(ModelProvider::new);
		pack.addProvider(ModLootTableProvider::new);
		pack.addProvider(BlockTagProvider::new);
		//pack.addProvider(ModRecipeProvider::new);
		pack.addProvider(ModRecipeProvider::new);
		pack.addProvider(ItemTagProvider::new);
		pack.addProvider(ModLangProvider::new);
		pack.addProvider(ModEnchantmentProvider::new);
		
	}



}
