package net.ent.entstupidstuff.api.IntTrait;

public interface IBluntTrait {
    // Marker interface, empty marker interface
}
