package net.ent.entstupidstuff.api.IntTrait;

public interface ICircleSlashTrait {
    // Marker interface, empty marker interface
}
