package net.ent.entstupidstuff.api.IntTrait;

public interface ITrait {
    // Marker interface for traits
}
