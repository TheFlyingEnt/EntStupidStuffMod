package net.ent.entstupidstuff.api.IntTrait;

public interface IBleedingTrait {

}
