package net.ent.entstupidstuff.mixin;

import net.ent.entstupidstuff.item.WeaponFactory;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.ItemRenderer;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.util.ModelIdentifier;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(ItemRenderer.class)
public abstract class ItemRendererMixin {
    @ModifyVariable(method = "renderItem", at = @At(value = "HEAD"), argsOnly = true)
    public BakedModel useRubyStaffModel(BakedModel value, ItemStack stack, ModelTransformationMode renderMode, boolean leftHanded, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, int overlay) {
        /*if (stack.isOf(WeaponFactory.getItem("stone_hammer")) && renderMode != ModelTransformationMode.GUI) { //Identifier.of("entstupidstuff")
            return ((ItemRendererAccessor) this).mccourse$getModels().getModelManager().getModel(new ModelIdentifier(Identifier.of("entstupidstuff", "diamond_hammer"), "inventory"));
        } 
        else if (stack.isOf(WeaponFactory.getItem("stone_hammer")) && renderMode != ModelTransformationMode.GROUND) { //Identifier.of("entstupidstuff")
            return ((ItemRendererAccessor) this).mccourse$getModels().getModelManager().getModel(new ModelIdentifier(Identifier.of("entstupidstuff", "diamond_hammer"), "ground"));
        }*/

        if (stack.isOf(WeaponFactory.getItem("wooden_hammer"))) {
            if (!renderMode.equals(ModelTransformationMode.GUI) && !renderMode.equals(ModelTransformationMode.GROUND)) {
                return ((ItemRendererAccessor) this).mccourse$getModels().getModelManager().getModel(new ModelIdentifier(Identifier.of("entstupidstuff", "wooden_hammer_model"), "inventory"));   
            } 
        }
        if (stack.isOf(WeaponFactory.getItem("stone_hammer"))) {
            if (!renderMode.equals(ModelTransformationMode.GUI) && !renderMode.equals(ModelTransformationMode.GROUND)) {
                return ((ItemRendererAccessor) this).mccourse$getModels().getModelManager().getModel(new ModelIdentifier(Identifier.of("entstupidstuff", "stone_hammer_model"), "inventory"));   
            } 
        }
        if (stack.isOf(WeaponFactory.getItem("iron_hammer"))) {
            if (!renderMode.equals(ModelTransformationMode.GUI) && !renderMode.equals(ModelTransformationMode.GROUND)) {
                return ((ItemRendererAccessor) this).mccourse$getModels().getModelManager().getModel(new ModelIdentifier(Identifier.of("entstupidstuff", "iron_hammer_model"), "inventory"));   
            } 
        }
        if (stack.isOf(WeaponFactory.getItem("golden_hammer"))) {
            if (!renderMode.equals(ModelTransformationMode.GUI) && !renderMode.equals(ModelTransformationMode.GROUND)) {
                return ((ItemRendererAccessor) this).mccourse$getModels().getModelManager().getModel(new ModelIdentifier(Identifier.of("entstupidstuff", "golden_hammer_model"), "inventory"));   
            } 
        }
        if (stack.isOf(WeaponFactory.getItem("diamond_hammer"))) {
            if (!renderMode.equals(ModelTransformationMode.GUI) && !renderMode.equals(ModelTransformationMode.GROUND)) {
                return ((ItemRendererAccessor) this).mccourse$getModels().getModelManager().getModel(new ModelIdentifier(Identifier.of("entstupidstuff", "diamond_hammer_model"), "inventory"));   
            } 
        }
        if (stack.isOf(WeaponFactory.getItem("netherite_hammer"))) {
            if (!renderMode.equals(ModelTransformationMode.GUI) && !renderMode.equals(ModelTransformationMode.GROUND)) {
                return ((ItemRendererAccessor) this).mccourse$getModels().getModelManager().getModel(new ModelIdentifier(Identifier.of("entstupidstuff", "netherite_hammer_model"), "inventory"));   
            } 
        }


        return value;

        //ModelIdentifier
    }
}