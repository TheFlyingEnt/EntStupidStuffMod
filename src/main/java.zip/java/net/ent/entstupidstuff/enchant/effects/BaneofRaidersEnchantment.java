package net.ent.entstupidstuff.enchant.effects;

public class BaneofRaidersEnchantment {

}
