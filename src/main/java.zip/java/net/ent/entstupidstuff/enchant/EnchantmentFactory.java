package net.ent.entstupidstuff.enchant;

import net.ent.entstupidstuff.EntStupidStuff;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;


public class EnchantmentFactory {

    //Codec Reg

    //public static final TagKey<Enchantment> ENT_ENCHANTMENTS = TagKey.of(RegistryKeys.ENCHANTMENT, Identifier.of(EntStupidStuff.MOD_ID, "ent_enchantments"));
   

    public static final RegistryKey<Enchantment> FROSTBITE = RegistryKey.of(RegistryKeys.ENCHANTMENT, Identifier.of(EntStupidStuff.MOD_ID, "frostbite"));
    public static final RegistryKey<Enchantment> BERSERK = RegistryKey.of(RegistryKeys.ENCHANTMENT, Identifier.of(EntStupidStuff.MOD_ID, "berserk"));
    public static final RegistryKey<Enchantment> BANEOFRAIDERS = RegistryKey.of(RegistryKeys.ENCHANTMENT, Identifier.of(EntStupidStuff.MOD_ID, "baneofraiders"));
    public static final RegistryKey<Enchantment> EXPERIENCE = RegistryKey.of(RegistryKeys.ENCHANTMENT, Identifier.of(EntStupidStuff.MOD_ID, "experience"));
    public static final RegistryKey<Enchantment> WALL_JUMP = RegistryKey.of(RegistryKeys.ENCHANTMENT, Identifier.of(EntStupidStuff.MOD_ID, "wall_jump"));
    public static final RegistryKey<Enchantment> OSMOSIS = RegistryKey.of(RegistryKeys.ENCHANTMENT, Identifier.of(EntStupidStuff.MOD_ID, "osmosis"));
    public static final RegistryKey<Enchantment> STAFE = RegistryKey.of(RegistryKeys.ENCHANTMENT, Identifier.of(EntStupidStuff.MOD_ID, "stafe"));
    //public static final RegistryKey<Enchantment> MAGIC_PROTECTION = RegistryKey.of(RegistryKeys.ENCHANTMENT, Identifier.of(EntStupidStuff.MOD_ID, "magic_protection"));
    public static final RegistryKey<Enchantment> LIGHTEN = RegistryKey.of(RegistryKeys.ENCHANTMENT, Identifier.of(EntStupidStuff.MOD_ID, "lighten"));
    public static final RegistryKey<Enchantment> STALWART = RegistryKey.of(RegistryKeys.ENCHANTMENT, Identifier.of(EntStupidStuff.MOD_ID, "stalwart"));
    public static final RegistryKey<Enchantment> SHIELD_BASH = RegistryKey.of(RegistryKeys.ENCHANTMENT, Identifier.of(EntStupidStuff.MOD_ID, "shield_bash"));
    public static final RegistryKey<Enchantment> SCORCHING = RegistryKey.of(RegistryKeys.ENCHANTMENT, Identifier.of(EntStupidStuff.MOD_ID, "scorching"));

    public static final RegistryKey<Enchantment> MAGIC_PROTECTION = RegistryKey.of(RegistryKeys.ENCHANTMENT, Identifier.of(EntStupidStuff.MOD_ID, "magic_protection"));

    //public static final TagKey<Enchantment> FROSTBITETAG = TagKey.of(RegistryKeys.ENCHANTMENT, Identifier.of(EntStupidStuff.MOD_ID, "frostbite"));


    public static void onInitialize() {
       ModCodec.onInitialize();
       ModComponentTypes.onInitialize();


       //Registry.ENCHANTMENT.addTag(FROSTBITETAG, FROSTBITE);

    }

}
