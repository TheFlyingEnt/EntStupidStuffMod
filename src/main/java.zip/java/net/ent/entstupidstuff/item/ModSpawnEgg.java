package net.ent.entstupidstuff.item;

import java.util.LinkedHashMap;
import java.util.Map;

import net.ent.entstupidstuff.EntStupidStuff;
import net.ent.entstupidstuff.registry.EntityFactory;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;

public class ModSpawnEgg {

    public static final Map<Identifier, Item> ItemList = new LinkedHashMap<>();

    public static final RegistryKey<ItemGroup> ENTSTUPIDSTUFF_ITEM_GROUP = RegistryKey.of(RegistryKeys.ITEM_GROUP, Identifier.of(EntStupidStuff.MOD_ID, "modded_group"));
    
    /*
    * Item Register
    */

    public static final Item ZOMBIE_LOBBER_SPAWN_EGG = Registry.register(Registries.ITEM,
        Identifier.of(EntStupidStuff.MOD_ID, "zombie_lobber_spawn_egg"),
        new SpawnEggItem(EntityFactory.LOBBER_ZOMBIE, 0x9CAE86, 0x39574B, new Item.Settings())
    );

    public static final Item ZOMBIE_SCORCHED_SPAWN_EGG = Registry.register(Registries.ITEM,
        Identifier.of(EntStupidStuff.MOD_ID, "zombie_scorched_spawn_egg"),
        new SpawnEggItem(EntityFactory.ZOMBIE_SCORCHED, 0x6D2729, 0xE38D2F, new Item.Settings())
    );

    public static final Item ZOMBIE_DEEPCRAWLE_SPAWN_EGG = Registry.register(Registries.ITEM,
        Identifier.of(EntStupidStuff.MOD_ID, "zombie_deepcrawle_spawn_egg"),
        new SpawnEggItem(EntityFactory.ZOMBIE_SCORCHED, 0x455A4D, 0x412220, new Item.Settings())
    );

    public static final Item ZOMBIE_GREALS_SPAWN_EGG = Registry.register(Registries.ITEM,
        Identifier.of(EntStupidStuff.MOD_ID, "zombie_greals_spawn_egg"),
        new SpawnEggItem(EntityFactory.ZOMBIE_SCORCHED, 0x6A873E, 0xA959B3, new Item.Settings())
    );

    /*
     * ZOMBIE_DEEPCRAWLE - 455A4D & 412220
     * ZOMBIE_ROTSPAWN -> Lobber Zombie Might be Renamed to RotSpawn
     * ZOMBIE_GREALS - 6A873E & A959B3
     * ZOMBIE_FROSTBITTEN
     * SOUL_SKELETON
     * SKELETON_WOLF
     * DIAMOND_ARMORED_PILLAGER - 923C0D & 4AEDD9
     * GOLD_ARMORED_PILLAGER    - 4D193C & EFB607
     * Guardian Vex             - D3A0C9 & E9E9E9
     * 
     */

    public static void onInitialize() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS).register(content -> {
            content.addAfter(
                ZOMBIE_LOBBER_SPAWN_EGG,
                ZOMBIE_LOBBER_SPAWN_EGG,
                ZOMBIE_SCORCHED_SPAWN_EGG,
                ZOMBIE_DEEPCRAWLE_SPAWN_EGG,
                ZOMBIE_GREALS_SPAWN_EGG
            );
        });
    }

}
