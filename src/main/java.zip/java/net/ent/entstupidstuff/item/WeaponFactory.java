package net.ent.entstupidstuff.item;

import java.util.LinkedHashMap;
import java.util.Map;

import net.ent.entstupidstuff.EntStupidStuff;
import net.ent.entstupidstuff.item.itemType.DaggerItem;
import net.ent.entstupidstuff.item.itemType.HammerItem;
import net.ent.entstupidstuff.item.itemType.LongSwordItem;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ToolItem;
import net.minecraft.item.ToolMaterials;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class WeaponFactory {

    public static final Map<Identifier, Item> ItemList = new LinkedHashMap<>(); //Mapping For Items
    public static final Map<Identifier, Item> ModelList = new LinkedHashMap<>(); //Mapping For Items

    public static final RegistryKey<ItemGroup> ENTSTUPIDSTUFF_COMBAT_GROUP = RegistryKey.of(RegistryKeys.ITEM_GROUP, Identifier.of(EntStupidStuff.MOD_ID, "combat_group")); //Registering Item Group

    public static final void Reg() {
        registerItems("wooden_dagger", new DaggerItem(ToolMaterials.WOOD, new Item.Settings()));
        registerItems("stone_dagger", new DaggerItem(ToolMaterials.STONE, new Item.Settings()));
        registerItems("golden_dagger", new DaggerItem(ToolMaterials.GOLD, new Item.Settings()));
        registerItems("iron_dagger", new DaggerItem(ToolMaterials.IRON, new Item.Settings()));
        registerItems("diamond_dagger", new DaggerItem(ToolMaterials.DIAMOND, new Item.Settings()));
        registerItems("netherite_dagger", new DaggerItem(ToolMaterials.NETHERITE, new Item.Settings().fireproof()));

        registerItems("wooden_hammer", new HammerItem(ToolMaterials.WOOD, new Item.Settings()));
        registerItems("stone_hammer", new HammerItem(ToolMaterials.STONE, new Item.Settings()));
        registerItems("golden_hammer", new HammerItem(ToolMaterials.GOLD, new Item.Settings()));
        registerItems("iron_hammer", new HammerItem(ToolMaterials.IRON, new Item.Settings()));
        registerItems("diamond_hammer", new HammerItem(ToolMaterials.DIAMOND, new Item.Settings()));
        registerItems("netherite_hammer", new HammerItem(ToolMaterials.NETHERITE, new Item.Settings().fireproof()));

        registerItems("wooden_long_sword", new LongSwordItem(ToolMaterials.WOOD, new Item.Settings()));
        registerItems("stone_long_sword", new LongSwordItem(ToolMaterials.STONE, new Item.Settings()));
        registerItems("golden_long_sword", new LongSwordItem(ToolMaterials.GOLD, new Item.Settings()));
        registerItems("iron_long_sword", new LongSwordItem(ToolMaterials.IRON, new Item.Settings()));
        registerItems("diamond_long_sword", new LongSwordItem(ToolMaterials.DIAMOND, new Item.Settings()));
        registerItems("netherite_long_sword", new LongSwordItem(ToolMaterials.NETHERITE, new Item.Settings().fireproof()));

    }

    public static void ModelReg() {
        registerModel("wooden_hammer_model", new ToolItem(ToolMaterials.WOOD, new Item.Settings()));
        registerModel("stone_hammer_model", new ToolItem(ToolMaterials.STONE, new Item.Settings()));
        registerModel("golden_hammer_model", new ToolItem(ToolMaterials.GOLD, new Item.Settings()));
        registerModel("iron_hammer_model", new ToolItem(ToolMaterials.IRON, new Item.Settings()));
        registerModel("diamond_hammer_model", new ToolItem(ToolMaterials.DIAMOND, new Item.Settings()));
        registerModel("netherite_hammer_model", new ToolItem(ToolMaterials.NETHERITE, new Item.Settings().fireproof()));
    }


    /**
     * Updated Weapon System:
     * Katana <--- Hammer <-- Dagger <--- LongSword <--- Battle Axe <--- Katana

     * 
     * Long Sword - Will now have Shirl Attack (Left Click) with new Particle + Two Handed
     * - Weapon Agisnt Shields, long cooldown for Shirl Attack
     * - Great Agist Hammer, Bad Agist 
     * 
     * Hammer - Blunt will now cause an AOT attack with new Particle Attack when charged + Two Handed
     * - Great Aginst Shield and Armor, Longest Cool-down for AOT
     * - Amazing Agist Dagger, Bad Agist Battle Axe
     * 
     * Katana - Will have First Strike + Block (Parry)
     * - Fast Attacking, Bad Agist Shields
     * 
     * Dagger - Will have Dual Wielding :)
     * - Fast Attacking, Bad Agist Shields
     * 
     * Battle Axe - Charge Attack what Deal massive Damage
     * - Great Aginst Shield
     * 
     * Long Bow - 1.25x damage when shot, but longer cool down (bow < x < cross-bow)
     * Heavy Cross-Bow - 1.25x damage when shot,, but longer coold down (x > crossbow)
     * 
     */

     /**
     * Updated Weapon System Alt:
     * Katana <--- Hammer <-- Dagger <--- LongSword <--- Battle Axe <--- Katana

     * 
     * Long Sword - Block Attack
     * - Weapon Agisnt Shields, long cooldown for Shirl Attack
     * - Great Agist Hammer, Bad Agist 
     * 
     * Hammer - Blunt will now cause an AOT attack with new Particle Attack when charged + Two Handed
     * - Great Aginst Shield and Armor, Longest Cool-down for AOT
     * - Amazing Agist Dagger, Bad Agist Battle Axe
     * 
     * Katana - Charge Attack
     * - Fast Attacking, Bad Agist Shields
     * 
     * Dagger - Will have Dual Wielding :)
     * - Fast Attacking, Bad Agist Shields
     * 
     * Battle Axe - Shirl Attack
     * - Great Aginst Shield
     * 
     * Long Bow - 1.25x damage when shot, but longer cool down (bow < x < cross-bow)
     * Heavy Cross-Bow - 1.25x damage when shot,, but longer coold down (x > crossbow)
     * 
     */




    
    public static <I extends Item> I registerModel(String name, I item) {
        ModelList.put(Identifier.of(EntStupidStuff.MOD_ID, name), item);
        return item;
    }

    public static <I extends Item> I registerItems(String name, I item) {
        ItemList.put(Identifier.of(EntStupidStuff.MOD_ID, name), item);
        return item;
    }

    public static Item getItem(String name) {
        return ItemList.get(Identifier.of(EntStupidStuff.MOD_ID, name));
    }

    public static void onInitialize() {

        WeaponFactory.Reg();
        WeaponFactory.ModelReg();

        //Registering: Combat Tab (Item Group)
        Registry.register(Registries.ITEM_GROUP, ENTSTUPIDSTUFF_COMBAT_GROUP, FabricItemGroup.builder()
        .icon(() -> new ItemStack(getItem("diamond_long_sword")))
        .displayName(Text.translatable("item.entstupidstuff.item_group"))
        .build());

        //Registering: Combat Items
        for (Identifier id : ItemList.keySet()) {
            Registry.register(Registries.ITEM, id, ItemList.get(id));
            ItemGroupEvents.modifyEntriesEvent(ENTSTUPIDSTUFF_COMBAT_GROUP).register(entries -> entries.add(ItemList.get(id)));
        }

        for (Identifier id : ModelList.keySet()) {
            Registry.register(Registries.ITEM, id, ModelList.get(id));
        }
    }
}
