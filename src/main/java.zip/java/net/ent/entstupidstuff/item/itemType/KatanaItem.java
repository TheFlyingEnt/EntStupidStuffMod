package net.ent.entstupidstuff.item.itemType;

import net.ent.entstupidstuff.item.base.WeaponItem;
import net.minecraft.item.ToolMaterial;

public class KatanaItem  extends WeaponItem{

    public KatanaItem(ToolMaterial toolMaterial, Settings settings) {
        super(toolMaterial, settings);
        //TODO Auto-generated constructor stub
    }

}
