package net.ent.entstupidstuff.item.itemType;

import java.util.List;

import net.ent.entstupidstuff.api.IntTrait.ICircleSlashTrait;
import net.ent.entstupidstuff.api.IntTrait.ITrait;
import net.ent.entstupidstuff.api.IntTrait.ITwoHandTrait;
import net.ent.entstupidstuff.item.base.WeaponItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.UseAction;




public class LongSwordItem extends SwordItem  implements ITwoHandTrait, ITrait, ICircleSlashTrait{

    //public float attack = 4;

    public LongSwordItem(ToolMaterial toolMaterial, Settings settings) {
        super(toolMaterial, settings.attributeModifiers(WeaponItem.createAttributeModifiers(toolMaterial, (5/*3.5*/)  + toolMaterial.getAttackDamage(), -2.6f, 1, 1, 0)));
        
        //material, baseAttackDamage (Added), attackSpeed (Added), toolReach (Added), attackSweep (Added)

    }

    // For 1.20.5+ Adding TwoHanded ToolTip
    @Override
    public void appendTooltip(ItemStack itemStack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.translatable("item.entstupidstuff.double_hand.tooltip").formatted(Formatting.GRAY));
    }

    @Override
	public UseAction getUseAction(ItemStack stack) {
		return UseAction.BLOCK;
	}

    
}
