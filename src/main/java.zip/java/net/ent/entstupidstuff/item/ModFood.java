package net.ent.entstupidstuff.item;

import net.ent.entstupidstuff.EntStupidStuff;
import net.ent.entstupidstuff.item.base.BottleOfRumItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModFood {

    public static final Item MARSHMELLOW_RAW = null;
    public static final Item MARSHMELLOW_TOASTED = null;
    public static final Item NOODEL_BOWL = null;
    public static final Item BAGGETTE = null;

    public static final Item RAW_URANIUM = null;

    public static final Item RAW_BRONZE = null;
    public static final Item BRONZE_INGOT = null;

    public static final Item ENDERC_DUST = null;
    public static final Item MUSHROOM_BLUE = null;

    //Pirate Life Update
    public static final Item RUM = new BottleOfRumItem(new Item.Settings());;
    public static final Item CAPRISUN = null;
    public static final Item FLINT_LOCK_COPPER = null;
    public static final Item ANCHOR = null;
    public static final Item CANNON_BALL = null;
    public static final Item CANNON = null;

    //Pillager Update
    public static final Item QUIVER_SUMMON = null;

    //Campfire Update

    //Of Fire and Gold Update

    public static void onInitialize() {
        Registry.register(Registries.ITEM, Identifier.of(EntStupidStuff.MOD_ID, "bottle_of_rum"), RUM);
    }


}
