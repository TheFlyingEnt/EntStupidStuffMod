package net.ent.entstupidstuff.block;

import net.fabricmc.fabric.api.registry.FlammableBlockRegistry;
import net.fabricmc.fabric.api.registry.OxidizableBlocksRegistry;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockSetType;
import net.minecraft.block.Blocks;
import net.minecraft.block.ButtonBlock;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.FenceBlock;
import net.minecraft.block.FenceGateBlock;
import net.minecraft.block.Oxidizable;
import net.minecraft.block.OxidizableDoorBlock;
import net.minecraft.block.PressurePlateBlock;
import net.minecraft.block.SlabBlock;
import net.minecraft.block.StairsBlock;
import net.minecraft.block.TrapdoorBlock;
import net.minecraft.block.WallBlock;
import net.minecraft.block.WoodType;
import net.minecraft.data.family.BlockFamilies;


public class BlockFactoryUtil {

    //Creates Wood Group (Trapdoor + Doors, Fences + fenceGate + Pressure Plates + Slab + Stair + button) //TODO: Handing Sign + Signs
    public static void addWoodFamily(String FamilyBase, String varient) {

        if (varient == null) {varient = "";}
        else {varient = "_" + varient;}

        Block PLANKS = BlockFactory.register(FamilyBase + "_planks" + varient, 
            new Block(AbstractBlock.Settings.copy(Blocks.OAK_PLANKS).mapColor(BlockFactory.getMapColor(varient))), true);
        Block TRAP_DOOR = BlockFactory.register(FamilyBase + "_trapdoor" + varient, 
            new TrapdoorBlock(BlockSetType.OAK, AbstractBlock.Settings.copy(Blocks.OAK_TRAPDOOR).mapColor(BlockFactory.getMapColor(varient))), true);
        Block FENCE = BlockFactory.register(FamilyBase + "_fence" + varient, 
            new FenceBlock(AbstractBlock.Settings.copy(Blocks.OAK_FENCE).mapColor(BlockFactory.getMapColor(varient))), true); 
        Block FENCE_GATE = BlockFactory.register(FamilyBase + "_fence_gate" + varient, 
            new FenceGateBlock(WoodType.OAK, AbstractBlock.Settings.copy(Blocks.OAK_FENCE_GATE).mapColor(BlockFactory.getMapColor(varient))), true); 
        Block P_PLATE = BlockFactory.register(FamilyBase + "_pressure_plate" + varient, 
            new PressurePlateBlock(BlockSetType.OAK, AbstractBlock.Settings.copy(Blocks.OAK_PRESSURE_PLATE).mapColor(BlockFactory.getMapColor(varient))), true); 
        Block SLAB = BlockFactory.register(FamilyBase + "_slab" + varient, 
            new SlabBlock(AbstractBlock.Settings.copy(Blocks.OAK_SLAB).mapColor(BlockFactory.getMapColor(varient))), true); 
        Block STAIRS = BlockFactory.register(FamilyBase + "_stairs" + varient, 
            new StairsBlock(PLANKS.getDefaultState(), AbstractBlock.Settings.copy(Blocks.OAK_STAIRS).mapColor(BlockFactory.getMapColor(varient))), true); 
        Block BUTTON = BlockFactory.register(FamilyBase + "_button" + varient, 
            new ButtonBlock(BlockSetType.OAK, 30, AbstractBlock.Settings.copy(Blocks.OAK_BUTTON).mapColor(BlockFactory.getMapColor(varient))), true); 
        Block DOOR = BlockFactory.register(FamilyBase + "_door" + varient, 
            new DoorBlock(BlockSetType.OAK, AbstractBlock.Settings.copy(Blocks.OAK_DOOR).nonOpaque().mapColor(BlockFactory.getMapColor(varient))), true);
        Block GLASS_DOOR = BlockFactory.register(FamilyBase + "_glass_door" + varient, 
            new DoorBlock(BlockSetType.OAK, AbstractBlock.Settings.copy(Blocks.OAK_DOOR).nonOpaque().mapColor(BlockFactory.getMapColor(varient))), true); 
        
        FlammableBlockRegistry.getDefaultInstance().add(PLANKS, 5, 20);
        FlammableBlockRegistry.getDefaultInstance().add(TRAP_DOOR, 5, 20);
        FlammableBlockRegistry.getDefaultInstance().add(FENCE_GATE, 5, 20);
        FlammableBlockRegistry.getDefaultInstance().add(FENCE_GATE, 5, 20);
        FlammableBlockRegistry.getDefaultInstance().add(P_PLATE, 5, 20);
        FlammableBlockRegistry.getDefaultInstance().add(SLAB, 5, 20);
        FlammableBlockRegistry.getDefaultInstance().add(STAIRS, 5, 20);
        FlammableBlockRegistry.getDefaultInstance().add(BUTTON, 5, 20);
        FlammableBlockRegistry.getDefaultInstance().add(DOOR, 5, 20);
        FlammableBlockRegistry.getDefaultInstance().add(GLASS_DOOR, 5, 20);

        BlockFamilies.register(PLANKS).button(BUTTON).fence(FENCE).fenceGate(FENCE_GATE).pressurePlate(P_PLATE).slab(SLAB).stairs(STAIRS).trapdoor(TRAP_DOOR)/* .sign(Sign, HSign) */.door(DOOR)
		.group("wooden")
        .unlockCriterionName("has_planks")
		.build();

        //ItemGroupEvents.modifyEntriesEvent(ItemGroups.BUILDING_BLOCKS).register(entries -> entries.add(PLANKS));

    }

    //Add Remaining Block for Alt Stones
    @SuppressWarnings("unused")
    public static void createVanillaAltStone(Block FamilyBlock, String FamilyName) {
        Block Bricks = BlockFactory.register(FamilyName + "_bricks", new Block(AbstractBlock.Settings.copy(FamilyBlock)), true);
        Block Stairs = BlockFactory.register(FamilyName + "_brick_stairs", new StairsBlock(Bricks.getDefaultState(), AbstractBlock.Settings.copy(FamilyBlock)), true); 
        //Block Cracked = BlockFactory.register(FamilyName + "_brick_bricks", new Block(AbstractBlock.Settings.copy(FamilyBlock)), true);
        Block Slab = BlockFactory.register(FamilyName + "_brick_slab", new SlabBlock(AbstractBlock.Settings.copy(FamilyBlock)), true);
        Block Wall = BlockFactory.register(FamilyName + "_brick_wall", new WallBlock(AbstractBlock.Settings.copy(FamilyBlock)), true);
        Block Chizeled = BlockFactory.register(FamilyName + "_brick_chiseled", new Block(AbstractBlock.Settings.copy(FamilyBlock)), true);
    }

    public static void addCopperFamily() {

        Block COPPER = BlockFactory.register("copper_glass_door", new OxidizableDoorBlock(BlockSetType.COPPER, Oxidizable.OxidationLevel.UNAFFECTED, AbstractBlock.Settings.copy(Blocks.COPPER_DOOR)), true);  
        Block EXPOSED_COPPER = BlockFactory.register("exposed_copper_glass_door", new OxidizableDoorBlock(BlockSetType.COPPER, Oxidizable.OxidationLevel.EXPOSED, AbstractBlock.Settings.copy(Blocks.COPPER_DOOR)), true);
        Block OXIDIZED_COPPER = BlockFactory.register("oxidized_copper_glass_door", new OxidizableDoorBlock(BlockSetType.COPPER, Oxidizable.OxidationLevel.OXIDIZED, AbstractBlock.Settings.copy(Blocks.COPPER_DOOR)), true);  
        Block WEATHERED_COPPER = BlockFactory.register("weathered_copper_glass_door", new OxidizableDoorBlock(BlockSetType.COPPER, Oxidizable.OxidationLevel.WEATHERED, AbstractBlock.Settings.copy(Blocks.COPPER_DOOR)), true);    

        Block WAXED_COPPER = BlockFactory.register("waxed_copper_glass_door", new DoorBlock(BlockSetType.COPPER, AbstractBlock.Settings.copy(COPPER)), true);  
        Block WAXED_EXPOSED_COPPER = BlockFactory.register("waxed_exposed_copper_glass_door", new DoorBlock(BlockSetType.COPPER, AbstractBlock.Settings.copy(EXPOSED_COPPER)), true);
        Block WAXED_OXIDIZED_COPPER = BlockFactory.register("waxed_oxidized_copper_glass_door", new DoorBlock(BlockSetType.COPPER, AbstractBlock.Settings.copy(OXIDIZED_COPPER)), true);  
        Block WAXED_WEATHERED_COPPER = BlockFactory.register("waxed_weathered_copper_glass_door", new DoorBlock(BlockSetType.COPPER, AbstractBlock.Settings.copy(WEATHERED_COPPER)), true);    
        
        OxidizableBlocksRegistry.registerOxidizableBlockPair(COPPER, EXPOSED_COPPER);
        OxidizableBlocksRegistry.registerOxidizableBlockPair(EXPOSED_COPPER, OXIDIZED_COPPER);
        OxidizableBlocksRegistry.registerOxidizableBlockPair(OXIDIZED_COPPER, WEATHERED_COPPER);
        
        OxidizableBlocksRegistry.registerWaxableBlockPair(COPPER, WAXED_COPPER);
        OxidizableBlocksRegistry.registerWaxableBlockPair(EXPOSED_COPPER, WAXED_EXPOSED_COPPER);
        OxidizableBlocksRegistry.registerWaxableBlockPair(OXIDIZED_COPPER, WAXED_OXIDIZED_COPPER);
        OxidizableBlocksRegistry.registerWaxableBlockPair(WEATHERED_COPPER, WAXED_WEATHERED_COPPER);

    }

    /*public void familyBuilder(Block base) {
        BlockFamilies.register(base)
        .button(Blocks.ACACIA_BUTTON)
		.fence(Blocks.ACACIA_FENCE)
		.fenceGate(Blocks.ACACIA_FENCE_GATE)
		.pressurePlate(Blocks.ACACIA_PRESSURE_PLATE)
		.sign(Blocks.ACACIA_SIGN, Blocks.ACACIA_WALL_SIGN)
		.slab(Blocks.ACACIA_SLAB)
		.stairs(Blocks.ACACIA_stairs)
		.door(Blocks.ACACIA_DOOR)
		.trapdoor(Blocks.ACACIA_TRAPDOOR)
		.group("wooden")
		.unlockCriterionName("has_planks")
		.build();
    }*/
}
