package net.ent.entstupidstuff.block;

import net.minecraft.client.render.RenderLayer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;


public class ModRenderLayers {

    public static void onInitializeClient() {

        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.MOD_DOOR("fungal", null), RenderLayer.getCutout());
        for (String color : BlockFactory.COLORS) {
            BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.MOD_DOOR("fungal", color), RenderLayer.getCutout());
            BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.MOD_DOOR("fungal_glass", color), RenderLayer.getCutout());

            /*BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.MOD_TRAPDOOR("fungal", color), RenderLayer.getCutout());*/
            /*BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.MOD_TRAPDOOR("fungal_glass", color), RenderLayer.getCutout());*/
        }

        for (String base : ModBlocks.V_WOOD_VARIENTS) {
            BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.MOD_DOOR(base + "_glass", null), RenderLayer.getCutout());
        }

        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.MOD_DOOR("iron" + "_glass", null), RenderLayer.getCutout());

        for (String base : ModBlocks.COPPER_VARIENTS) {
            BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.MOD_DOOR(base + "_glass", null), RenderLayer.getCutout());
        }

        //BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.MOD_DOOR("oak_glass", null), RenderLayer.getCutout());
        //BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.MOD_DOOR("spruce_glass", null), RenderLayer.getCutout());
        //BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.MOD_DOOR("birch_glass", null), RenderLayer.getCutout());
       // BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.MOD_DOOR("jungle_glass", null), RenderLayer.getCutout());
        //BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.MOD_DOOR("acacia_glass", null), RenderLayer.getCutout());
        //BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.MOD_DOOR("dark_oak_glass", null), RenderLayer.getCutout());
        //BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.MOD_DOOR("mangrove_glass", null), RenderLayer.getCutout());
        //BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.MOD_DOOR("cherry_glass", null), RenderLayer.getCutout());
        //BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.MOD_DOOR("crimson_glass", null), RenderLayer.getCutout());
        //BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.MOD_DOOR("warped_glass", null), RenderLayer.getCutout());

        /*BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.MOD_TRAPDOOR("oak_glass", null), RenderLayer.getCutout());*/
        /*BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.MOD_TRAPDOOR("spruce_glass", null), RenderLayer.getCutout());*/
        /*BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.MOD_TRAPDOOR("birch_glass", null), RenderLayer.getCutout());*/
        /*BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.MOD_TRAPDOOR("jungle_glass", null), RenderLayer.getCutout());*/
        /*BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.MOD_TRAPDOOR("acacia_glass", null), RenderLayer.getCutout());*/
        /*BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.MOD_TRAPDOOR("dark_oak_glass", null), RenderLayer.getCutout());*/
        /*BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.MOD_TRAPDOOR("mangrove_glass", null), RenderLayer.getCutout());*/
        /*BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.MOD_TRAPDOOR("cherry_glass", null), RenderLayer.getCutout());*/
        /*BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.MOD_TRAPDOOR("crimson_glass", null), RenderLayer.getCutout());*/
        /*BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.MOD_TRAPDOOR("warped_glass", null), RenderLayer.getCutout());*/
    }
}
