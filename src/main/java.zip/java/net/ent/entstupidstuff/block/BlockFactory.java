package net.ent.entstupidstuff.block;

import java.util.LinkedHashMap;
import java.util.Map;

import net.ent.entstupidstuff.EntStupidStuff;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.registry.FlammableBlockRegistry;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockSetType;
import net.minecraft.block.Blocks;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.MapColor;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;


//TODO: Clean-up Code
public class BlockFactory {

    public final static String[] COLORS = {"white", "light_gray", "gray", "black", "brown", "red", "orange", "yellow", "lime", "green", "cyan", "light_blue", "blue", "purple", "magenta", "pink"};
    
    public static final Map<Identifier, Block> FULLBLOCKS = new LinkedHashMap<>(); //Every Block Added
    //public static final Map<Identifier, Block> FUNGAL_PLANKS = new LinkedHashMap<>(); //Every Fungal Planks + Colored Planks
    //public static final Map<Identifier, Block> TEXTURED_WOOL = new LinkedHashMap<>(); //Every Textured Wool

    public static final RegistryKey<ItemGroup> ENTSTUPIDSTUFF_DECO = RegistryKey.of(RegistryKeys.ITEM_GROUP, Identifier.of(EntStupidStuff.MOD_ID, "ent_deco_group")); //Registering Item Group

    
    public static void onInitialize() {

        Registry.register(Registries.ITEM_GROUP, ENTSTUPIDSTUFF_DECO, FabricItemGroup.builder()
        .icon(() -> new ItemStack(getBlock("fungal_planks_cyan").asItem()))
        .displayName(Text.translatable("item.entstupidstuff.deco_group"))
        .build());


        BlockFactoryUtil.addWoodFamily("fungal", null);
        for (String color : COLORS) {BlockFactoryUtil.addWoodFamily("fungal", color);}
        for (String color : COLORS) {createTexturedWool(color);}

        BlockFactoryUtil.addCopperFamily();
        register("iron" + "_glass_door", new DoorBlock(BlockSetType.IRON, AbstractBlock.Settings.copy(Blocks.IRON_DOOR)), true);
        for (String varient : ModBlocks.V_WOOD_VARIENTS) {addVanillaWoodFamily(varient);}

        BlockFactoryUtil.createVanillaAltStone(Blocks.POLISHED_ANDESITE, "polished_andesite");
        BlockFactoryUtil.createVanillaAltStone(Blocks.POLISHED_GRANITE, "polished_granite");
        BlockFactoryUtil.createVanillaAltStone(Blocks.POLISHED_DIORITE, "polished_diorite");

        /*createVanillaStoneFamily()*/
        /*createVanillaGlassDoor()*/
        /*createModGlassDoor()*/
        /*createLogVarient()*/
        /*createChiseledOre()*/


        /*for (Identifier id : FUNGAL_PLANKS.keySet()) {
            ItemGroupEvents.modifyEntriesEvent(ItemGroups.BUILDING_BLOCKS).register(entries -> entries.add(FUNGAL_PLANKS.get(id)));
        }

        for (Identifier id : TEXTURED_WOOL.keySet()) {
            ItemGroupEvents.modifyEntriesEvent(ItemGroups.COLORED_BLOCKS).register(entries -> entries.add(TEXTURED_WOOL.get(id)));
        }*/


    }

    public static void addVanillaWoodFamily(String varient) {

        BlockSetType bst;
        //"oak", "spruce", "jungle", "birch", "dark_oak", "acacia","mangrove", "cherry", "bamboo", "warped", "crimson"
        if (varient == "oak") bst = BlockSetType.OAK;
        else if (varient == "spruce") bst = BlockSetType.SPRUCE;
        else if (varient == "jungle") bst = BlockSetType.JUNGLE;
        else if (varient == "birch") bst = BlockSetType.BIRCH;
        else if (varient == "dark_oak") bst = BlockSetType.DARK_OAK;
        else if (varient == "acacia") bst = BlockSetType.ACACIA;
        else if (varient == "mangrove") bst = BlockSetType.MANGROVE;
        else if (varient == "cherry") bst = BlockSetType.CHERRY;
        else if (varient == "bamboo") bst = BlockSetType.BAMBOO;
        else if (varient == "warped") bst = BlockSetType.WARPED;
        else if (varient == "crimson") bst = BlockSetType.CRIMSON;
        else bst = BlockSetType.OAK;
        

        Block Glass_Door = register(varient + "_glass_door", 
            new DoorBlock(bst, AbstractBlock.Settings.copy(ModBlocks.VANILLA_DOOR(varient))), true);
        
        if (varient != "warped" || varient != "crimson") {
            FlammableBlockRegistry.getDefaultInstance().add(Glass_Door, 5, 20);}

    }

    public static void createTexturedWool(String color) {

        register("textured_wool_" + color,
		    new Block(AbstractBlock.Settings.copy(getWoolColor(color))),true);
        FlammableBlockRegistry.getDefaultInstance().add((getBlock("textured_wool_" + color)), 30, 60);
        
    }


    public static Block register(String name, Block block, boolean regItem) {

        Identifier id = Identifier.of(EntStupidStuff.MOD_ID, name);
        if (regItem) {
            BlockItem blockItem = new BlockItem(block, new Item.Settings());
			Registry.register(Registries.ITEM, id, blockItem);
        }
        FULLBLOCKS.put(Identifier.of(EntStupidStuff.MOD_ID, name), block);

        ItemGroupEvents.modifyEntriesEvent(ENTSTUPIDSTUFF_DECO).register(entries -> entries.add(FULLBLOCKS.get(id).asItem()));
        return Registry.register(Registries.BLOCK, id, block);
	}
    
    public static Block getBlock(String blockID) {
        return FULLBLOCKS.get(Identifier.of(EntStupidStuff.MOD_ID, blockID));
    }

    public static MapColor getMapColor(String covColor) {
        if (covColor == "white") {return MapColor.WHITE;}
        if (covColor == "light_gray") {return MapColor.LIGHT_GRAY;}
        if (covColor == "gray") {return MapColor.GRAY;}
        if (covColor == "black") {return MapColor.BLACK;}
        if (covColor == "brown") {return MapColor.BROWN;}
        if (covColor == "red") {return MapColor.RED;}
        if (covColor == "orange") {return MapColor.ORANGE;}
        if (covColor == "yellow") {return MapColor.YELLOW;}
        if (covColor == "lime") {return MapColor.LIME;}
        if (covColor == "green") {return MapColor.GREEN;}
        if (covColor == "cyan") {return MapColor.CYAN;}
        if (covColor == "light_blue") {return MapColor.LIGHT_BLUE;}
        if (covColor == "blue") {return MapColor.BLUE;}
        if (covColor == "purple") {return MapColor.PURPLE;}
        if (covColor == "magenta") {return MapColor.MAGENTA;}
        if (covColor == "pink") {return MapColor.PINK;}
        else {return MapColor.OFF_WHITE;}
    }

    public static Block getWoolColor(String covColor) {
        if (covColor == "white") {return Blocks.WHITE_WOOL;}
        if (covColor == "light_gray") {return Blocks.LIGHT_GRAY_WOOL;}
        if (covColor == "gray") {return Blocks.GRAY_WOOL;}
        if (covColor == "black") {return Blocks.BLACK_WOOL;}
        if (covColor == "brown") {return Blocks.BROWN_WOOL;}
        if (covColor == "red") {return Blocks.RED_WOOL;}
        if (covColor == "orange") {return Blocks.ORANGE_WOOL;}
        if (covColor == "yellow") {return Blocks.YELLOW_WOOL;}
        if (covColor == "lime") {return Blocks.LIME_WOOL;}
        if (covColor == "green") {return Blocks.GREEN_WOOL;}
        if (covColor == "cyan") {return Blocks.CYAN_WOOL;}
        if (covColor == "light_blue") {return Blocks.LIGHT_BLUE_WOOL;}
        if (covColor == "blue") {return Blocks.BLUE_WOOL;}
        if (covColor == "purple") {return Blocks.PURPLE_WOOL;}
        if (covColor == "magenta") {return Blocks.MAGENTA_WOOL;}
        if (covColor == "pink") {return Blocks.PINK_WOOL;}
        else {return Blocks.WHITE_WOOL;}
    }

    public static Item getDye(String covColor) {
        if (covColor == "white") {return Items.WHITE_DYE;}
        if (covColor == "light_gray") {return Items.LIGHT_GRAY_DYE;}
        if (covColor == "gray") {return Items.GRAY_DYE;}
        if (covColor == "black") {return Items.BLACK_DYE;}
        if (covColor == "brown") {return Items.BROWN_DYE;}
        if (covColor == "red") {return Items.RED_DYE;}
        if (covColor == "orange") {return Items.ORANGE_DYE;}
        if (covColor == "yellow") {return Items.YELLOW_DYE;}
        if (covColor == "lime") {return Items.LIME_DYE;}
        if (covColor == "green") {return Items.GREEN_DYE;}
        if (covColor == "cyan") {return Items.CYAN_DYE;}
        if (covColor == "light_blue") {return Items.LIGHT_BLUE_DYE;}
        if (covColor == "blue") {return Items.BLUE_DYE;}
        if (covColor == "purple") {return Items.PURPLE_DYE;}
        if (covColor == "magenta") {return Items.MAGENTA_DYE;}
        if (covColor == "pink") {return Items.PINK_DYE;}
        else {return Items.WHITE_DYE;}
    }

    

}
