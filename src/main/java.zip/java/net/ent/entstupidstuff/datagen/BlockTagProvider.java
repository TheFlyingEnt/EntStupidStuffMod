package net.ent.entstupidstuff.datagen;

import java.util.concurrent.CompletableFuture;

import net.ent.entstupidstuff.block.BlockFactory;
import net.ent.entstupidstuff.block.ModBlocks;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.fabricmc.fabric.api.registry.FlammableBlockRegistry;
import net.minecraft.registry.RegistryWrapper.WrapperLookup;
import net.minecraft.registry.tag.BlockTags;

public class BlockTagProvider extends FabricTagProvider.BlockTagProvider{

    public BlockTagProvider(FabricDataOutput output, CompletableFuture<WrapperLookup> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected void configure(WrapperLookup wrapperLookup) {

        //Fungal Planks
        addWoodFamily("fungal", null);
        for (String color : BlockFactory.COLORS) {addWoodFamily("fungal", color);}
        for (String color : BlockFactory.COLORS) {addWoolFamily("textured_wool", color);}

        addVanillaStoneFamily("polished_granite_brick");
        addVanillaStoneFamily("polished_diorite_brick");
        addVanillaStoneFamily("polished_andesite_brick");

        /*addVanillaDoorFamily("oak");*/
        for (String wood : ModBlocks.V_WOOD_VARIENTS) {addVanillaGlassDoor(wood);}

        addVanillaGlassDoorM("iron");

        for (String c : ModBlocks.COPPER_VARIENTS) {addVanillaGlassDoorM(c);}

        
        
    }

    public void addWoodFamily(String FamilyBase, String varient) {

        if (varient == null) {varient = "";}
        else {varient = "_" + varient;}

        getOrCreateTagBuilder(BlockTags.PLANKS)
            .add((BlockFactory.getBlock(FamilyBase + "_planks" + varient)));
        getOrCreateTagBuilder(BlockTags.LOGS_THAT_BURN)
            .add((BlockFactory.getBlock(FamilyBase + "_planks" + varient)));
        getOrCreateTagBuilder(BlockTags.WOODEN_BUTTONS)
            .add((BlockFactory.getBlock(FamilyBase + "_button" + varient)));
        getOrCreateTagBuilder(BlockTags.WOODEN_DOORS)
            .add((BlockFactory.getBlock(FamilyBase + "_door" + varient)));
        getOrCreateTagBuilder(BlockTags.WOODEN_FENCES)
            .add((BlockFactory.getBlock(FamilyBase + "_fence" + varient)));
        getOrCreateTagBuilder(BlockTags.WOODEN_FENCES)
            .add((BlockFactory.getBlock(FamilyBase + "_fence_gate" + varient)));
        getOrCreateTagBuilder(BlockTags.WOODEN_PRESSURE_PLATES)
            .add((BlockFactory.getBlock(FamilyBase + "_pressure_plate" + varient)));
        getOrCreateTagBuilder(BlockTags.WOODEN_SLABS)
            .add((BlockFactory.getBlock(FamilyBase + "_slab" + varient)));
        getOrCreateTagBuilder(BlockTags.WOODEN_STAIRS)
            .add((BlockFactory.getBlock(FamilyBase + "_stairs" + varient)));
        getOrCreateTagBuilder(BlockTags.WOODEN_TRAPDOORS)
            .add((BlockFactory.getBlock(FamilyBase + "_trapdoor" + varient)));
        getOrCreateTagBuilder(BlockTags.WOODEN_DOORS)
            .add((BlockFactory.getBlock(FamilyBase + "_glass_door" + varient)));
        //Add Hanging Sign + Sign 

        FlammableBlockRegistry.getDefaultInstance()
            .add((BlockFactory.getBlock(FamilyBase + "_planks" + varient)), 5, 20);
        FlammableBlockRegistry.getDefaultInstance()
            .add((BlockFactory.getBlock(FamilyBase + "_button" + varient)), 5, 20);
        FlammableBlockRegistry.getDefaultInstance()
            .add((BlockFactory.getBlock(FamilyBase + "_fence" + varient)), 5, 20);
        FlammableBlockRegistry.getDefaultInstance()
            .add((BlockFactory.getBlock(FamilyBase + "_fence_gate" + varient)), 5, 20);
        FlammableBlockRegistry.getDefaultInstance()
            .add((BlockFactory.getBlock(FamilyBase + "_pressure_plate" + varient)), 5, 20);
        FlammableBlockRegistry.getDefaultInstance()
            .add((BlockFactory.getBlock(FamilyBase + "_slab" + varient)), 5, 20);
        FlammableBlockRegistry.getDefaultInstance()
            .add((BlockFactory.getBlock(FamilyBase + "_stairs" + varient)), 5, 20);
        FlammableBlockRegistry.getDefaultInstance()
            .add((BlockFactory.getBlock(FamilyBase + "_trapdoor" + varient)), 5, 20);
        FlammableBlockRegistry.getDefaultInstance()
            .add((BlockFactory.getBlock(FamilyBase + "_door" + varient)), 5, 20);
        FlammableBlockRegistry.getDefaultInstance()
            .add((BlockFactory.getBlock(FamilyBase + "_glass_door" + varient)), 5, 20);
        //Add Hanging Sign + Sign 


    }

    public void addWoolFamily(String FamilyBase, String color){
        getOrCreateTagBuilder(BlockTags.WOOL)
            .add((BlockFactory.getBlock(FamilyBase + "_" + color)));

        FlammableBlockRegistry.getDefaultInstance()
            .add((BlockFactory.getBlock(FamilyBase + "_" + color)), 30, 60);
    }

    public void addVanillaGlassDoor(String FamilyBase){
        getOrCreateTagBuilder(BlockTags.WOODEN_DOORS)
            .add((BlockFactory.getBlock(FamilyBase + "_glass_door")));

        FlammableBlockRegistry.getDefaultInstance()
            .add((BlockFactory.getBlock(FamilyBase + "_glass_door")), 5, 20);
    }

    public void addVanillaGlassDoorM(String FamilyBase){
        getOrCreateTagBuilder(BlockTags.DOORS)
            .add((BlockFactory.getBlock(FamilyBase + "_glass_door")));

        getOrCreateTagBuilder(BlockTags.PICKAXE_MINEABLE)
            .add((BlockFactory.getBlock(FamilyBase + "_glass_door")));

        if (FamilyBase != "iron"){ //For Copper Doors
            getOrCreateTagBuilder(BlockTags.MOB_INTERACTABLE_DOORS)
                .add((BlockFactory.getBlock(FamilyBase + "_glass_door")));

            getOrCreateTagBuilder(BlockTags.INCORRECT_FOR_WOODEN_TOOL)
                .add((BlockFactory.getBlock(FamilyBase + "_glass_door")));

            getOrCreateTagBuilder(BlockTags.INCORRECT_FOR_GOLD_TOOL)
                .add((BlockFactory.getBlock(FamilyBase + "_glass_door")));

            getOrCreateTagBuilder(BlockTags.NEEDS_STONE_TOOL)
                .add((BlockFactory.getBlock(FamilyBase + "_glass_door")));
        }
    }

    

    public void addVanillaStoneFamily(String FamilyBase) {
        getOrCreateTagBuilder(BlockTags.STAIRS)
            .add((BlockFactory.getBlock(FamilyBase + "_stairs")));
        getOrCreateTagBuilder(BlockTags.SLABS)
            .add((BlockFactory.getBlock(FamilyBase + "_slab")));
        getOrCreateTagBuilder(BlockTags.WALLS)
            .add((BlockFactory.getBlock(FamilyBase + "_wall")));

        getOrCreateTagBuilder(BlockTags.PICKAXE_MINEABLE)
            .add((BlockFactory.getBlock(FamilyBase + "s")));
        getOrCreateTagBuilder(BlockTags.PICKAXE_MINEABLE)
            .add((BlockFactory.getBlock(FamilyBase + "_stairs")));
        getOrCreateTagBuilder(BlockTags.PICKAXE_MINEABLE)
            .add((BlockFactory.getBlock(FamilyBase + "_slab")));
        getOrCreateTagBuilder(BlockTags.PICKAXE_MINEABLE)
            .add((BlockFactory.getBlock(FamilyBase + "_wall")));
    }


    @Deprecated
    public void addWoodTags(String base, String endTag){ 
        getOrCreateTagBuilder(BlockTags.WOODEN_BUTTONS).add((BlockFactory.getBlock(base + "_button" + endTag)));
        getOrCreateTagBuilder(BlockTags.WOODEN_DOORS).add((BlockFactory.getBlock(base + "_door" + endTag)));
        getOrCreateTagBuilder(BlockTags.WOODEN_FENCES).add((BlockFactory.getBlock(base + "_fence" + endTag)));
        getOrCreateTagBuilder(BlockTags.WOODEN_FENCES).add((BlockFactory.getBlock(base + "_fence_gate" + endTag)));
        getOrCreateTagBuilder(BlockTags.WOODEN_PRESSURE_PLATES).add((BlockFactory.getBlock(base + "_pressure_plate" + endTag)));
        getOrCreateTagBuilder(BlockTags.WOODEN_SLABS).add((BlockFactory.getBlock(base + "_slab" + endTag)));
        getOrCreateTagBuilder(BlockTags.WOODEN_STAIRS).add((BlockFactory.getBlock(base + "_stairs" + endTag)));
        getOrCreateTagBuilder(BlockTags.WOODEN_TRAPDOORS).add((BlockFactory.getBlock(base + "_trapdoor" + endTag)));

        FlammableBlockRegistry.getDefaultInstance().add((BlockFactory.getBlock(base + "_button" + endTag)), 5, 20);
        FlammableBlockRegistry.getDefaultInstance().add((BlockFactory.getBlock(base + "_fence" + endTag)), 5, 20);
        FlammableBlockRegistry.getDefaultInstance().add((BlockFactory.getBlock(base + "_fence_gate" + endTag)), 5, 20);
        FlammableBlockRegistry.getDefaultInstance().add((BlockFactory.getBlock(base + "_pressure_plate" + endTag)), 5, 20);
        FlammableBlockRegistry.getDefaultInstance().add((BlockFactory.getBlock(base + "_slab" + endTag)), 5, 20);
        FlammableBlockRegistry.getDefaultInstance().add((BlockFactory.getBlock(base + "_stairs" + endTag)), 5, 20);
        FlammableBlockRegistry.getDefaultInstance().add((BlockFactory.getBlock(base + "_trapdoor" + endTag)), 5, 20);

    }
    
}
