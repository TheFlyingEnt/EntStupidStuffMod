package net.ent.entstupidstuff.datagen;

import java.util.concurrent.CompletableFuture;

import net.ent.entstupidstuff.block.BlockFactory;
import net.ent.entstupidstuff.block.ModBlocks;
import net.ent.entstupidstuff.item.WeaponFactory;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricLanguageProvider;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.RegistryWrapper.WrapperLookup;

public class ModLangProvider extends FabricLanguageProvider  {

    public ModLangProvider(FabricDataOutput dataOutput, CompletableFuture<RegistryWrapper.WrapperLookup> registryLookup) {
        super(dataOutput, "en_us", registryLookup);
    }
    

    public ModLangProvider(FabricDataOutput dataOutput, String languageCode, CompletableFuture<WrapperLookup> registryLookup) {
        super(dataOutput, "en_us", registryLookup);
    }

    @Override
    public void generateTranslations(WrapperLookup registryLookup, TranslationBuilder translationBuilder) {

        translationBuilder.add(BlockFactory.getBlock("fungal_planks"), "Fungal Planks");
        translationBuilder.add(BlockFactory.getBlock("fungal_stairs"), "Fungal Stairs");
        translationBuilder.add(BlockFactory.getBlock("fungal_slab"), "Fungal Slab");
        translationBuilder.add(BlockFactory.getBlock("fungal_fence"), "Fungal Fence");
        translationBuilder.add(BlockFactory.getBlock("fungal_fence_gate"), "Fungal Fence Gate");
        translationBuilder.add(BlockFactory.getBlock("fungal_door"), "Fungal Door");
        translationBuilder.add(BlockFactory.getBlock("fungal_trapdoor"), "Fungal Trapdoor");
        translationBuilder.add(BlockFactory.getBlock("fungal_pressure_plate"), "Fungal Pressure Plate");
        translationBuilder.add(BlockFactory.getBlock("fungal_button"), "Fungal Button");
        translationBuilder.add(BlockFactory.getBlock("fungal_glass_door"), "Fungal Glass Door");


        for (String color : BlockFactory.COLORS){
            translationBuilder.add(BlockFactory.getBlock("fungal_planks_" + color), formatString(color) + " Fungal Planks");
            translationBuilder.add(BlockFactory.getBlock("fungal_stairs_" + color), formatString(color) + " Fungal Stairs");
            translationBuilder.add(BlockFactory.getBlock("fungal_slab_" + color), formatString(color) + " Fungal Slab");
            translationBuilder.add(BlockFactory.getBlock("fungal_fence_" + color), formatString(color) + " Fungal Fence");
            translationBuilder.add(BlockFactory.getBlock("fungal_fence_gate_" + color), formatString(color) + " Fungal Fence Gate");
            translationBuilder.add(BlockFactory.getBlock("fungal_door_" + color), formatString(color) + " Fungal Door");
            translationBuilder.add(BlockFactory.getBlock("fungal_trapdoor_" + color), formatString(color) + " Fungal Trapdoor");
            translationBuilder.add(BlockFactory.getBlock("fungal_pressure_plate_" + color), formatString(color) + " Fungal Pressure Plate");
            translationBuilder.add(BlockFactory.getBlock("fungal_button_" + color), formatString(color) + " Fungal Button");
            translationBuilder.add(BlockFactory.getBlock("fungal_glass_door_" + color), formatString(color) + " Fungal Glass Door");
        }

        for (String color : BlockFactory.COLORS){
            translationBuilder.add(BlockFactory.getBlock("textured_wool_" + color), formatString(color) + " Quillted Wool");
        }

        for (String varient : ModBlocks.COPPER_VARIENTS){
            translationBuilder.add(BlockFactory.getBlock(varient + "_glass_door"), formatString(varient) + " Glass Door");
        }

        for (String varient : ModBlocks.V_WOOD_VARIENTS){
            translationBuilder.add(BlockFactory.getBlock(varient + "_glass_door"), formatString(varient) + " Glass Door");
        }

        translationBuilder.add(BlockFactory.getBlock("iron_glass_door"),"Iron Glass Door");

        translationBuilder.add(WeaponFactory.getItem("wooden_dagger"), "Wooden Dagger");
        translationBuilder.add(WeaponFactory.getItem("stone_dagger"), "Stone Dagger");
        translationBuilder.add(WeaponFactory.getItem("iron_dagger"), "Iron Dagger");
        translationBuilder.add(WeaponFactory.getItem("golden_dagger"), "Golden Dagger");
        translationBuilder.add(WeaponFactory.getItem("diamond_dagger"), "Diamond Dagger");
        translationBuilder.add(WeaponFactory.getItem("netherite_dagger"), "Netherite Dagger");

        translationBuilder.add(WeaponFactory.getItem("wooden_long_sword"), "Wooden Long Sword");
        translationBuilder.add(WeaponFactory.getItem("stone_long_sword"), "Stone Long Sword");
        translationBuilder.add(WeaponFactory.getItem("iron_long_sword"), "Iron Long Sword");
        translationBuilder.add(WeaponFactory.getItem("golden_long_sword"), "Golden Long Sword");
        translationBuilder.add(WeaponFactory.getItem("diamond_long_sword"), "Diamond Long Sword");
        translationBuilder.add(WeaponFactory.getItem("netherite_long_sword"), "Netherite Long Sword");

        translationBuilder.add(WeaponFactory.getItem("wooden_hammer"), "Wooden Hammer");
        translationBuilder.add(WeaponFactory.getItem("stone_hammer"), "Stone Hammer");
        translationBuilder.add(WeaponFactory.getItem("iron_hammer"), "Iron Hammer");
        translationBuilder.add(WeaponFactory.getItem("golden_hammer"), "Golden Hammer");
        translationBuilder.add(WeaponFactory.getItem("diamond_hammer"), "Diamond Hammer");
        translationBuilder.add(WeaponFactory.getItem("netherite_hammer"), "Netherite Hammer");

        translationBuilder.add("item.entstupidstuff.double_hand.tooltip", "Double Handed");
        translationBuilder.add("item.entstupidstuff.blunt.tooltip", "Blunt");
        translationBuilder.add("item.entstupidstuff.bleeding.tooltip", "Bleed");

        translationBuilder.add("item.entstupidstuff.deco_group", "Decoration");
        translationBuilder.add("item.entstupidstuff.item_group", "Modded Combat");

        translationBuilder.add(BlockFactory.getBlock("polished_diorite_bricks"), "Polished Diorite Bricks");
        translationBuilder.add(BlockFactory.getBlock("polished_diorite_brick_slab"), "Polished Diorite Brick Slab");
        translationBuilder.add(BlockFactory.getBlock("polished_diorite_brick_stairs"), "Polished Diorite Brick Stair");
        translationBuilder.add(BlockFactory.getBlock("polished_diorite_brick_wall"), "Polished Diorite Brick Wall");
        translationBuilder.add(BlockFactory.getBlock("polished_diorite_brick_chiseled"), "Chiseled Polished Diorite Brick Wall");

        translationBuilder.add(BlockFactory.getBlock("polished_andesite_bricks"), "Polished Andesite Bricks");
        translationBuilder.add(BlockFactory.getBlock("polished_andesite_brick_slab"), "Polished Andesite Brick Slab");
        translationBuilder.add(BlockFactory.getBlock("polished_andesite_brick_stairs"), "Polished Andesite Brick Stair");
        translationBuilder.add(BlockFactory.getBlock("polished_andesite_brick_wall"), "Polished Andesite Brick Wall");
        translationBuilder.add(BlockFactory.getBlock("polished_andesite_brick_chiseled"), "Chiseled Polished Andesite Brick Wall");

        translationBuilder.add(BlockFactory.getBlock("polished_granite_bricks"), "Polished Granite Bricks");
        translationBuilder.add(BlockFactory.getBlock("polished_granite_brick_slab"), "Polished Granite Brick Slab");
        translationBuilder.add(BlockFactory.getBlock("polished_granite_brick_stairs"), "Polished Granite Brick Stair");
        translationBuilder.add(BlockFactory.getBlock("polished_granite_brick_wall"), "Polished Granite Brick Wall");
        translationBuilder.add(BlockFactory.getBlock("polished_granite_brick_chiseled"), "Chiseled Polished Granite Brick Wall");


        /*translationBuilder.add(SIMPLE_ITEM, "Simple Item");
        translationBuilder.add(SIMPLE_BLOCK, "Simple Block");
        translationBuilder.add(SIMPLE_ITEM_GROUP, "Simple Item Group");*/
     
        // Load an existing language file.
        /*try {
            Path existingFilePath = dataOutput.getModContainer().findPath("assets/entstupidstuff/lang/en_us.existing.json").get();
            translationBuilder.add(existingFilePath);
        } catch (Exception e) {
            throw new RuntimeException("Failed to add existing language file!", e);
        }*/
    }

    public static String formatString(String input) {
        String withSpaces = input.replace("_", " ");
        String[] words = withSpaces.split(" ");
        
        StringBuilder formattedString = new StringBuilder();
        for (String word : words) {
            if (word.length() > 0) {
                formattedString.append(Character.toUpperCase(word.charAt(0)))
                               .append(word.substring(1).toLowerCase())
                               .append(" ");
            }
        }
        
        return formattedString.toString().trim();
    }
 
    

}
