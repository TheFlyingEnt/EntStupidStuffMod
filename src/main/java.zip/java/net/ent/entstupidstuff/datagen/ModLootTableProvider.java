package net.ent.entstupidstuff.datagen;

import java.util.concurrent.CompletableFuture;

import net.ent.entstupidstuff.block.BlockFactory;
import net.ent.entstupidstuff.block.ModBlocks;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.minecraft.registry.RegistryWrapper;

public class ModLootTableProvider extends FabricBlockLootTableProvider  {

    public ModLootTableProvider(FabricDataOutput dataOutput, CompletableFuture<RegistryWrapper.WrapperLookup> registryLookup) {
        super(dataOutput, registryLookup);
    }

    @Override
    public void generate() {

        generateWoodType("fungal", null);
        for (String color : BlockFactory.COLORS) {generateWoodType("fungal", color);}
        for (String color : BlockFactory.COLORS) {addDrop((BlockFactory.getBlock("textured_wool_" + color)));};
        createVanillaGlassDoor();
    }

    public void createVanillaGlassDoor(){

        for (String FamilyBase : ModBlocks.V_WOOD_VARIENTS) {
            addDrop((BlockFactory.getBlock(FamilyBase + "_glass_door")), doorDrops(BlockFactory.getBlock(FamilyBase + "_glass_door")));
            //addDrop((BlockFactory.getBlock(FamilyBase + "_glass_trapdoor")));
        }

        addDrop((BlockFactory.getBlock("iron" + "_glass_door")), doorDrops(BlockFactory.getBlock("iron" + "_glass_door")));

        /*for (String FamilyBase : ModBlocks.COPPER_VARIENTS) {
            addDrop((BlockFactory.getBlock(FamilyBase + "_glass_door")), doorDrops(BlockFactory.getBlock(FamilyBase + "_glass_door")));
            //addDrop((BlockFactory.getBlock(FamilyBase + "_glass_trapdoor")));
        }*/
    }

    public void generateWoodType(String FamilyBase, String varient){

        if (varient == null) {varient = "";}
        else {varient = "_" + varient;}

        addDrop((BlockFactory.getBlock(FamilyBase + "_planks" + varient)));
        addDrop((BlockFactory.getBlock(FamilyBase + "_trapdoor" + varient)));
        addDrop((BlockFactory.getBlock(FamilyBase + "_fence" + varient)));
        addDrop((BlockFactory.getBlock(FamilyBase + "_fence_gate" + varient)));
        addDrop((BlockFactory.getBlock(FamilyBase + "_pressure_plate" + varient)));
        addDrop((BlockFactory.getBlock(FamilyBase + "_slab" + varient)), slabDrops(BlockFactory.getBlock(FamilyBase + "_slab" + varient)));
        addDrop((BlockFactory.getBlock(FamilyBase + "_stairs" + varient)));
        addDrop((BlockFactory.getBlock(FamilyBase + "_button" + varient)));
        addDrop((BlockFactory.getBlock(FamilyBase + "_door" + varient)), doorDrops(BlockFactory.getBlock(FamilyBase + "_door" + varient)));
        addDrop((BlockFactory.getBlock(FamilyBase + "_glass_door" + varient)), doorDrops(BlockFactory.getBlock(FamilyBase + "_glass_door" + varient)));

    }

}
