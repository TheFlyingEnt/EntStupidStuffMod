package net.ent.entstupidstuff.datagen;

import net.ent.entstupidstuff.block.BlockFactory;
import net.ent.entstupidstuff.block.ModBlocks;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricModelProvider;
import net.minecraft.block.Block;
import net.minecraft.data.client.BlockStateModelGenerator;
import net.minecraft.data.client.BlockStateModelGenerator.BlockTexturePool;
import net.minecraft.data.client.ItemModelGenerator;

public class ModelProvider extends FabricModelProvider{

    public ModelProvider(FabricDataOutput output) {
        super(output);
    }
    
    BlockStateModelGenerator blockStateModelGenerator;

    @Override
    public void generateBlockStateModels(BlockStateModelGenerator blockStateModelGenerator2) {

        this.blockStateModelGenerator = blockStateModelGenerator2;

        addWoodFamily("fungal", null);
        for (String color : BlockFactory.COLORS) {addWoodFamily("fungal", color);}
        for (String color : BlockFactory.COLORS) {addWoolFamily("textured_wool", color);}

        for (String base : ModBlocks.V_WOOD_VARIENTS) {createVanillaGlassDoor(base);}
        createVanillaGlassDoor("iron");
        for (String c : ModBlocks.COPPER_VARIENTS) {createVanillaGlassDoor(c);}

        addStoneAlt("polished_andesite");
        addStoneAlt("polished_diorite");
        addStoneAlt("polished_granite");

        
        






















		/*for (Block inputB : MBlockFactory.FULLBLOCKS.values()) {
			blockStateModelGenerator.registerSimpleCubeAll(inputB);  
		}*/
        
        /*createWoodTexG("fungal", blockStateModelGenerator, "");
        for (String inputC : MBlockFactory.COLORS) { createWoodTexG("fungal", blockStateModelGenerator, "_" + inputC);}
        for (String inputC : MBlockFactory.COLORS) { createColorT("textured_wool_" + inputC, blockStateModelGenerator);}*/
	}

    public void addWoodFamily(String Familybase, String varient) {

        if (varient == null) {varient = "";}
        else {varient = "_" + varient;}

        Block MainTexture = BlockFactory.getBlock(Familybase + "_planks" + varient);
        BlockTexturePool blockPool = blockStateModelGenerator.registerCubeAllModelTexturePool(MainTexture);

        blockPool
            .stairs(BlockFactory.getBlock(Familybase + "_stairs" + varient))
            .slab(BlockFactory.getBlock(Familybase + "_slab" + varient))
            .button(BlockFactory.getBlock(Familybase + "_button" + varient))
            .pressurePlate(BlockFactory.getBlock(Familybase + "_pressure_plate" + varient))
            .fence(BlockFactory.getBlock(Familybase + "_fence" + varient))
            .fenceGate(BlockFactory.getBlock(Familybase + "_fence_gate" + varient));
            
        blockStateModelGenerator.registerTrapdoor(BlockFactory.getBlock(Familybase + "_trapdoor" + varient));
        blockStateModelGenerator.registerDoor(BlockFactory.getBlock(Familybase + "_door" + varient));
        blockStateModelGenerator.registerDoor(BlockFactory.getBlock(Familybase + "_glass_door" + varient));
    }

    public void createVanillaGlassDoor(String Familybase) {
        if (Familybase == "waxed_copper") {}
        else if (Familybase == "waxed_exposed_copper") {} 
        else if (Familybase == "waxed_oxidized_copper") {} 
        else if (Familybase == "waxed_weathered_copper") {}
        else {blockStateModelGenerator.registerDoor(BlockFactory.getBlock(Familybase + "_glass_door"));}
    }

    public void addWoolFamily(String FamilyBase, String color) {
        blockStateModelGenerator.registerSimpleCubeAll(BlockFactory.getBlock(FamilyBase + "_" + color));
    }

    public void addStoneAlt(String FamilyBase) {
        Block MainTexture = BlockFactory.getBlock(FamilyBase + "_bricks");
        BlockTexturePool blockPool = blockStateModelGenerator.registerCubeAllModelTexturePool(MainTexture);

        blockPool
            .stairs(BlockFactory.getBlock(FamilyBase + "_brick_stairs"))
            .slab(BlockFactory.getBlock(FamilyBase + "_brick_slab"))
            .wall(BlockFactory.getBlock(FamilyBase + "_brick_wall"));

    }







    @Override
    public void generateItemModels(ItemModelGenerator itemModelGenerator) {
        // Unused for Now
    }

    /**
     *  Annocument: New Post-Text subline - Applied to Wood Type
     * [Base Item] + [Type] + [Color]
     * 
     */

     @Deprecated
    public void createColorT(String name, BlockStateModelGenerator blockStateModelGenerator) {
        blockStateModelGenerator.registerSimpleCubeAll(BlockFactory.getBlock(name));
    }

    @Deprecated
    public void createWoodTexG(String name, BlockStateModelGenerator blockStateModelGenerator, String endTag) { //TODO: Door, Sign, Hanging Sign

        System.out.println("Model: " + name + "_[Type]" + endTag);
        Block block = BlockFactory.getBlock(name + "_planks" + endTag);
        BlockTexturePool blockPool = blockStateModelGenerator.registerCubeAllModelTexturePool(block);

        blockPool.stairs(BlockFactory.getBlock(name + "_stairs" + endTag));
        blockPool.slab(BlockFactory.getBlock(name + "_slab" + endTag));
        blockPool.button(BlockFactory.getBlock(name + "_button" + endTag));
        blockPool.pressurePlate(BlockFactory.getBlock(name + "_pressure_plate" + endTag));
        blockPool.fence(BlockFactory.getBlock(name + "_fence" + endTag));
        blockPool.fenceGate(BlockFactory.getBlock(name + "_fence_gate" + endTag));
        blockStateModelGenerator.registerTrapdoor(BlockFactory.getBlock(name + "_trapdoor" + endTag));
        blockStateModelGenerator.registerDoor(BlockFactory.getBlock(name + "_door" + endTag));
    }

}
