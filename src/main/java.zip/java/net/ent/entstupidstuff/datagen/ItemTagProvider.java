package net.ent.entstupidstuff.datagen;

import java.util.concurrent.CompletableFuture;

import net.ent.entstupidstuff.EntStupidStuff;
import net.ent.entstupidstuff.block.BlockFactory;
import net.ent.entstupidstuff.block.ModBlocks;
import net.ent.entstupidstuff.item.WeaponFactory;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.item.Item;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.RegistryWrapper.WrapperLookup;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.Identifier;

public class ItemTagProvider extends FabricTagProvider.ItemTagProvider{

    public static final TagKey<Item> LONG_SWORD = of("long_sword");
    public static final TagKey<Item> BATTLE_AXE = of("battle_axe");
    public static final TagKey<Item> DAGGER = of("dagger");
    public static final TagKey<Item> KATANA = of("katana");
    public static final TagKey<Item> HAMMER = of("hammer");

    public ItemTagProvider(FabricDataOutput output, CompletableFuture<WrapperLookup> completableFuture) {
        super(output, completableFuture);
    }

    @Override
    protected void configure(WrapperLookup wrapperLookup) {

        addWoodFamily("fungal", null);
        for (String color : BlockFactory.COLORS) {addWoodFamily("fungal", color);}
        for (String color : BlockFactory.COLORS) {addWoolFamily("textured_wool", color);}
        /*for (String tm : MBlockFactory.TOOL_MATERIAL) {addCombatFamily("tm");}*/
        for (String wood : ModBlocks.V_WOOD_VARIENTS) {addVanillaGlassDoor(wood);}
        addVanillaGlassDoor("iron");

        for (String c : ModBlocks.COPPER_VARIENTS) {addVanillaGlassDoor(c);}

        addCombatFamily("wooden");
        addCombatFamily("golden");
        addCombatFamily("stone");
        addCombatFamily("iron");
        addCombatFamily("diamond");
        addCombatFamily("netherite");















        
        //Setting For Fungal wood
        /*setWoodGroupTags("fungal", "");

        //Setting for Color Types (Colored Fungal + Texture Wool)
        for (String inputC : MBlockFactory.COLORS) {
            setWoodGroupTags("fungal", "_" + inputC);
            getOrCreateTagBuilder(ItemTags.WOOL).add(MBlockFactory.getBlock("textured_wool_" + inputC).asItem());
        }*/
    }

    private static TagKey<Item> of(String id) {
		return TagKey.of(RegistryKeys.ITEM, Identifier.of(EntStupidStuff.MOD_ID, id));
	}

    public void addWoodFamily(String FamilyBase, String varient) {

        if (varient == null) {varient = "";}
        else {varient = "_" + varient;}

        getOrCreateTagBuilder(ItemTags.PLANKS)
            .add((BlockFactory.getBlock(FamilyBase + "_planks" + varient).asItem()));
        getOrCreateTagBuilder(ItemTags.LOGS_THAT_BURN)
            .add((BlockFactory.getBlock(FamilyBase + "_planks" + varient).asItem()));
        getOrCreateTagBuilder(ItemTags.WOODEN_BUTTONS)
            .add((BlockFactory.getBlock(FamilyBase + "_button" + varient).asItem()));
        getOrCreateTagBuilder(ItemTags.WOODEN_DOORS)
            .add((BlockFactory.getBlock(FamilyBase + "_door" + varient).asItem()));
        getOrCreateTagBuilder(ItemTags.WOODEN_FENCES)
            .add((BlockFactory.getBlock(FamilyBase + "_fence" + varient).asItem()));
        getOrCreateTagBuilder(ItemTags.WOODEN_FENCES)
            .add((BlockFactory.getBlock(FamilyBase + "_fence_gate" + varient).asItem()));
        getOrCreateTagBuilder(ItemTags.WOODEN_PRESSURE_PLATES)
            .add((BlockFactory.getBlock(FamilyBase + "_pressure_plate" + varient).asItem()));
        getOrCreateTagBuilder(ItemTags.WOODEN_SLABS)
            .add((BlockFactory.getBlock(FamilyBase + "_slab" + varient).asItem()));
        getOrCreateTagBuilder(ItemTags.WOODEN_STAIRS)
            .add((BlockFactory.getBlock(FamilyBase + "_stairs" + varient).asItem()));
        getOrCreateTagBuilder(ItemTags.WOODEN_TRAPDOORS)
            .add((BlockFactory.getBlock(FamilyBase + "_trapdoor" + varient).asItem()));
        getOrCreateTagBuilder(ItemTags.WOODEN_DOORS)
            .add((BlockFactory.getBlock(FamilyBase + "_glass_door" + varient).asItem()));
        //Add Hanging Sign + Sign 

    }

    public void addVanillaGlassDoor(String FamilyBase) {
        getOrCreateTagBuilder(ItemTags.WOODEN_DOORS)
            .add((BlockFactory.getBlock(FamilyBase + "_glass_door").asItem()));
    }

    public void addWoolFamily(String FamilyBase, String color){
        getOrCreateTagBuilder(ItemTags.WOOL)
            .add((BlockFactory.getBlock(FamilyBase + "_" + color).asItem()));
    }

    public void addCombatFamily(String tm){
        getOrCreateTagBuilder(LONG_SWORD).add(WeaponFactory.getItem(tm + "_long_sword"));
        //getOrCreateTagBuilder(BATTLE_AXE).add(WeaponFactory.getItem(tm + "_battle_axe"));
        getOrCreateTagBuilder(DAGGER).add(WeaponFactory.getItem(tm + "_dagger"));
        //getOrCreateTagBuilder(KATANA).add(WeaponFactory.getItem(tm + "_katana"));
        getOrCreateTagBuilder(HAMMER).add(WeaponFactory.getItem(tm + "_hammer"));

        //Enchantments
        getOrCreateTagBuilder(ItemTags.SWORD_ENCHANTABLE).add(WeaponFactory.getItem(tm + "_long_sword"));
        getOrCreateTagBuilder(ItemTags.SWORD_ENCHANTABLE).add(WeaponFactory.getItem(tm + "_dagger"));
        //getOrCreateTagBuilder(ItemTags.SWORD_ENCHANTABLE).add(WeaponFactory.getItem(tm + "_katana"));

        //Battle Axe Enchantments
        //getOrCreateTagBuilder(ItemTags.SHARP_WEAPON_ENCHANTABLE).add(WeaponFactory.getItem(tm + "_battle_axe"));

        //WEAPON ENCHANTABLE
        getOrCreateTagBuilder(ItemTags.WEAPON_ENCHANTABLE).add(WeaponFactory.getItem(tm + "_long_sword"));
        //getOrCreateTagBuilder(ItemTags.WEAPON_ENCHANTABLE).add(WeaponFactory.getItem(tm + "_battle_axe"));
        getOrCreateTagBuilder(ItemTags.WEAPON_ENCHANTABLE).add(WeaponFactory.getItem(tm + "_dagger"));
        //getOrCreateTagBuilder(ItemTags.WEAPON_ENCHANTABLE).add(WeaponFactory.getItem(tm + "_katana"));
        getOrCreateTagBuilder(ItemTags.WEAPON_ENCHANTABLE).add(WeaponFactory.getItem(tm + "_hammer"));

        //FIRE ASPECT ENCHANTABLE
        getOrCreateTagBuilder(ItemTags.FIRE_ASPECT_ENCHANTABLE).add(WeaponFactory.getItem(tm + "_long_sword"));
        //getOrCreateTagBuilder(ItemTags.FIRE_ASPECT_ENCHANTABLE).add(WeaponFactory.getItem(tm + "_battle_axe"));
        getOrCreateTagBuilder(ItemTags.FIRE_ASPECT_ENCHANTABLE).add(WeaponFactory.getItem(tm + "_dagger"));

        //Add Long Bows
    }











    //Used to Set a Wood Blocks Tags
    @Deprecated
    public void setWoodGroupTags(String baseName, String entTag) {

        getOrCreateTagBuilder(ItemTags.PLANKS).add(BlockFactory.getBlock(baseName + "_planks" + entTag).asItem());
        getOrCreateTagBuilder(ItemTags.WOODEN_STAIRS).add(BlockFactory.getBlock(baseName + "_stairs" + entTag).asItem());
        getOrCreateTagBuilder(ItemTags.WOODEN_SLABS).add(BlockFactory.getBlock(baseName + "_slab" + entTag).asItem());
        getOrCreateTagBuilder(ItemTags.WOODEN_BUTTONS).add(BlockFactory.getBlock(baseName + "_button" + entTag).asItem());
        getOrCreateTagBuilder(ItemTags.WOODEN_PRESSURE_PLATES).add(BlockFactory.getBlock(baseName + "_pressure_plate" + entTag).asItem());
        getOrCreateTagBuilder(ItemTags.WOODEN_BUTTONS).add(BlockFactory.getBlock(baseName + "_fence" + entTag).asItem());
        getOrCreateTagBuilder(ItemTags.WOODEN_FENCES).add(BlockFactory.getBlock(baseName + "_fence_gate" + entTag).asItem());
        getOrCreateTagBuilder(ItemTags.WOODEN_TRAPDOORS).add(BlockFactory.getBlock(baseName + "_trapdoor" + entTag).asItem());
        getOrCreateTagBuilder(ItemTags.WOODEN_DOORS).add(BlockFactory.getBlock(baseName + "_door" + entTag).asItem());

        getOrCreateTagBuilder(ItemTags.PLANKS).add(BlockFactory.getBlock(baseName + "_planks" + entTag).asItem());
        getOrCreateTagBuilder(ItemTags.STAIRS).add(BlockFactory.getBlock(baseName + "_stairs" + entTag).asItem());
        getOrCreateTagBuilder(ItemTags.SLABS).add(BlockFactory.getBlock(baseName + "_slab" + entTag).asItem());
        getOrCreateTagBuilder(ItemTags.BUTTONS).add(BlockFactory.getBlock(baseName + "_button" + entTag).asItem());
        getOrCreateTagBuilder(ItemTags.FENCES).add(BlockFactory.getBlock(baseName + "_fence" + entTag).asItem());
        getOrCreateTagBuilder(ItemTags.FENCE_GATES).add(BlockFactory.getBlock(baseName + "_fence_gate" + entTag).asItem());
        getOrCreateTagBuilder(ItemTags.TRAPDOORS).add(BlockFactory.getBlock(baseName + "_trapdoor" + entTag).asItem());
        getOrCreateTagBuilder(ItemTags.DOORS).add(BlockFactory.getBlock(baseName + "_door" + entTag).asItem());
    }

}
