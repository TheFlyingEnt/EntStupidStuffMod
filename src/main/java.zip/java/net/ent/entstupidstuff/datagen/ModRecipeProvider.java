package net.ent.entstupidstuff.datagen;

import java.util.concurrent.CompletableFuture;
import java.util.ArrayList;

import net.ent.entstupidstuff.block.BlockFactory;
import net.ent.entstupidstuff.block.ModBlocks;
import net.ent.entstupidstuff.item.WeaponFactory;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.data.server.recipe.CookingRecipeJsonBuilder;
import net.minecraft.data.server.recipe.RecipeExporter;
import net.minecraft.data.server.recipe.RecipeProvider;
import net.minecraft.data.server.recipe.ShapedRecipeJsonBuilder;
import net.minecraft.data.server.recipe.ShapelessRecipeJsonBuilder;
import net.minecraft.item.Item;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.Items;
import net.minecraft.recipe.Ingredient;
import net.minecraft.recipe.book.RecipeCategory;
import net.minecraft.registry.RegistryWrapper.WrapperLookup;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.registry.tag.TagKey;

public class ModRecipeProvider extends FabricRecipeProvider{

    public ModRecipeProvider(FabricDataOutput output, CompletableFuture<WrapperLookup> registriesFuture) {
        super(output, registriesFuture);
    }

    public static RecipeExporter exporter;

    @Override
    public void generate(RecipeExporter exporter2) {
        
        exporter = exporter2;

        createCombat(Items.STICK, "wooden", ItemTags.PLANKS);
        createCombat(Items.COBBLESTONE, "stone", ItemTags.STONE_TOOL_MATERIALS);
        createCombat(Items.IRON_INGOT, "iron");
        createCombat(Items.GOLD_INGOT, "golden");
        createCombat(Items.DIAMOND, "diamond");

        generateWoodFamily("fungal", null);
        for (String color : BlockFactory.COLORS) {generateColorPlank(color);}
        for (String color : BlockFactory.COLORS) {generateWoodFamily("fungal", color);}
        for (String color : BlockFactory.COLORS) {generateWoolFamily("textured_wool", color);}

        smeltToGold(); //Hardcoded
        smeltToIron(); //Hardcoded 
        /* smeltToCopper(); //Hardcoded */ //TODO: implement copper smelting

        for (String base : ModBlocks.V_WOOD_VARIENTS) {createVanillaGlassDoor(base);}
        for (String base : ModBlocks.COPPER_VARIENTS) {createVanillaGlassDoorC(base);}
        createVanillaGlassDoorI();


        createPlanks(BlockFactory.getBlock("fungal_planks"), Ingredient.ofItems(Blocks.MUSHROOM_STEM, Blocks.RED_MUSHROOM_BLOCK, Blocks.BROWN_MUSHROOM_BLOCK));
        
        createStoneVarient();































        //Combat Items
        /*ModRecipeProvider.createModdedWeapon(Items.STICK, "wooden", ItemTags.PLANKS);
        ModRecipeProvider.createModdedWeapon(Items.COBBLESTONE, "stone", ItemTags.STONE_TOOL_MATERIALS);
        ModRecipeProvider.createModdedWeapon(Items.IRON_INGOT, "iron");
        ModRecipeProvider.createModdedWeapon(Items.GOLD_INGOT, "golden");
        ModRecipeProvider.createModdedWeapon(Items.DIAMOND, "diamond");

        //Fungal Wood
        createWoodGroup("fungal", "");

        //Colored Wood + Planks
        for (String inputC : MBlockFactory.COLORS) {
            Item dye = MBlockFactory.getDye(inputC);
            ModRecipeProvider.createColorPlanks(dye, MBlockFactory.getBlock("fungal_planks_" + inputC), inputC);
        }*/

    }

    public void createCombat(Item UNLOCK, String MatName, TagKey<Item> matTag) {

        createLongSword(UNLOCK, WeaponFactory.getItem(MatName + "_long_sword"), matTag);
        createDagger(UNLOCK, WeaponFactory.getItem(MatName + "_dagger"), matTag);
        createHammer(UNLOCK, WeaponFactory.getItem(MatName + "_hammer"), matTag);
        //createBattleAxe(UNLOCK, WeaponFactory.getItem(MatName + "_battle_axe"), matTag);
        //createKatana(UNLOCK, WeaponFactory.getItem(MatName + "_katana"), matTag);

    }

    public void createCombat(Item Material, String MatName) {

        createLongSword(Material, WeaponFactory.getItem(MatName + "_long_sword"));
        createDagger(Material, WeaponFactory.getItem(MatName + "_dagger"));
        createHammer(Material, WeaponFactory.getItem(MatName + "_hammer"));
        //createBattleAxe(UNLOCK, WeaponFactory.getItem(MatName + "_battle_axe"));
        //createKatana(UNLOCK, WeaponFactory.getItem(MatName + "_katana"));

    }

    public static void createLongSword(Item UNLOCK, ItemConvertible result, TagKey<Item> ITEMTAGS){
        ShapedRecipeJsonBuilder.create(RecipeCategory.COMBAT, result)
        .input('#', ITEMTAGS)
        .input('X', Items.STICK)
        .pattern(" # ")
        .pattern("###")
        .pattern("#X#")
        .group("long_sword")
        .criterion(hasItem(UNLOCK), conditionsFromTag(ITEMTAGS))
        .offerTo(exporter);
    }

    public static void createLongSword(Item MATERIAL, ItemConvertible result){
        ShapedRecipeJsonBuilder.create(RecipeCategory.COMBAT, result)
        .input('#', MATERIAL)
        .input('X', Items.STICK)
        .pattern(" # ")
        .pattern("#X#")
        .pattern("#X#")
        .group("long_sword")
        .criterion(hasItem(MATERIAL), conditionsFromItem(MATERIAL))
        .offerTo(exporter);

        
    }

    public static void createBattleAxe(Item UNLOCK, ItemConvertible result, TagKey<Item> ITEMTAGS){
        ShapedRecipeJsonBuilder.create(RecipeCategory.COMBAT, result)
        .input('#', ITEMTAGS)
        .input('X', Items.STICK)
        .pattern("###")
        .pattern("#X#")
        .pattern(" X ")
        .group("battle_axe")
        .criterion(hasItem(UNLOCK), conditionsFromTag(ITEMTAGS))
        .offerTo(exporter);
    }

    public static void createBattleAxe(Item MATERIAL, ItemConvertible result){
        ShapedRecipeJsonBuilder.create(RecipeCategory.COMBAT, result)
        .input('#', MATERIAL)
        .input('X', Items.STICK)
        .pattern("###")
        .pattern("#X#")
        .pattern(" X ")
        .group("battle_axe")
        .criterion(hasItem(MATERIAL), conditionsFromItem(MATERIAL))
        .offerTo(exporter);

        
    }

    public static void createKatana(Item UNLOCK, ItemConvertible result, TagKey<Item> ITEMTAGS){
        ShapedRecipeJsonBuilder.create(RecipeCategory.COMBAT, result)
        .input('#', ITEMTAGS)
        .input('X', Items.STICK)
        .pattern("  #")
        .pattern(" # ")
        .pattern("X  ")
        .group("katana")
        .criterion(hasItem(UNLOCK), conditionsFromTag(ITEMTAGS))
        .offerTo(exporter);
    }

    public static void createKatana(Item MATERIAL, ItemConvertible result){
        ShapedRecipeJsonBuilder.create(RecipeCategory.COMBAT, result)
        .input('#', MATERIAL)
        .input('X', Items.STICK)
        .pattern("  #")
        .pattern(" # ")
        .pattern("X  ")
        .group("katana")
        .criterion(hasItem(MATERIAL), conditionsFromItem(MATERIAL))
        .offerTo(exporter);

        
    }

    public static void createDagger(Item UNLOCK, ItemConvertible result, TagKey<Item> ITEMTAGS){
        ShapedRecipeJsonBuilder.create(RecipeCategory.COMBAT, result)
        .input('#', ITEMTAGS)
        .input('X', Items.STICK)
        .pattern("  #")
        .pattern(" X ")
        .pattern("   ")
        .group("dagger")
        .criterion(hasItem(UNLOCK), conditionsFromTag(ITEMTAGS))
        .offerTo(exporter);
    }

    public static void createDagger(Item MATERIAL, ItemConvertible result){
        ShapedRecipeJsonBuilder.create(RecipeCategory.COMBAT, result)
        .input('#', MATERIAL)
        .input('X', Items.STICK)
        .pattern("  #")
        .pattern(" X ")
        .pattern("   ")
        .group("dagger")
        .criterion(hasItem(MATERIAL), conditionsFromItem(MATERIAL))
        .offerTo(exporter);

        
    }

    public static void createHammer(Item UNLOCK, ItemConvertible result, TagKey<Item> ITEMTAGS){
        ShapedRecipeJsonBuilder.create(RecipeCategory.COMBAT, result)
        .input('#', ITEMTAGS)
        .input('X', Items.STICK)
        .pattern("###")
        .pattern("###")
        .pattern(" X ")
        .group("hammer")
        .criterion(hasItem(UNLOCK), conditionsFromTag(ITEMTAGS))
        .offerTo(exporter);
    }

    public static void createHammer(Item MATERIAL, ItemConvertible result){
        ShapedRecipeJsonBuilder.create(RecipeCategory.COMBAT, result)
        .input('#', MATERIAL)
        .input('X', Items.STICK)
        .pattern("###")
        .pattern("###")
        .pattern(" X ")
        .group("hammer")
        .criterion(hasItem(MATERIAL), conditionsFromItem(MATERIAL))
        .offerTo(exporter);

        
    }

    public static void smeltToIron(){

        Item Iron1 = WeaponFactory.getItem("iron_long_sword");
        Item Iron2 = WeaponFactory.getItem("iron_long_sword");
        Item Iron3 = WeaponFactory.getItem("iron_long_sword");
        
        CookingRecipeJsonBuilder.createSmelting(
            Ingredient.ofItems(Iron1, Iron2, Iron3),
            RecipeCategory.MISC,
			Items.IRON_NUGGET,
			0.1F,
			200
        )
        .criterion(hasItem(Iron1), conditionsFromItem(Iron1))
        .criterion(hasItem(Iron2), conditionsFromItem(Iron2))
        .criterion(hasItem(Iron3), conditionsFromItem(Iron3))
		.offerTo(exporter, getSmeltingItemPath(Items.IRON_NUGGET));

    }

    public static void smeltToGold(){

        Item Gold1 = WeaponFactory.getItem("golden_long_sword");
        Item Gold2 = WeaponFactory.getItem("golden_long_sword");
        Item Gold3 = WeaponFactory.getItem("golden_long_sword");
        
        CookingRecipeJsonBuilder.createSmelting(
            Ingredient.ofItems(Gold1, Gold2, Gold3),
            RecipeCategory.MISC,
			Items.GOLD_NUGGET,
			0.1F,
			200
        )
        .criterion(hasItem(Gold1), conditionsFromItem(Gold1))
        .criterion(hasItem(Gold2), conditionsFromItem(Gold2))
        .criterion(hasItem(Gold3), conditionsFromItem(Gold3))
		.offerTo(exporter, getSmeltingItemPath(Items.GOLD_NUGGET));

    }

    public static void generateWoodFamily(String FamilyBase, String varient){

        if (varient == null) {varient = "";}
        else {varient = "_" + varient;}

        Item FamilyHead = BlockFactory.getBlock(FamilyBase + "_planks" + varient).asItem();
        Ingredient FamilyI = Ingredient.ofItems(FamilyHead);

        RecipeProvider
            .createTrapdoorRecipe(BlockFactory.getBlock(FamilyBase + "_trapdoor" + varient).asItem(), FamilyI)
            .group("wooden_trapdoor")
            .criterion(hasItem(FamilyHead), conditionsFromItem(FamilyHead))
            .offerTo(exporter);

        RecipeProvider
            .createFenceRecipe(BlockFactory.getBlock(FamilyBase + "_fence" + varient).asItem(), FamilyI)
            .group("wooden_fence")
            .criterion(hasItem(FamilyHead), conditionsFromItem(FamilyHead))
            .offerTo(exporter);
    
        RecipeProvider
            .createFenceGateRecipe(BlockFactory.getBlock(FamilyBase + "_fence_gate" + varient).asItem(), FamilyI)
            .group("wooden_fence_gate")
            .criterion(hasItem(FamilyHead), conditionsFromItem(FamilyHead))
            .offerTo(exporter);
    
        RecipeProvider
            .createPressurePlateRecipe(RecipeCategory.BUILDING_BLOCKS, BlockFactory.getBlock(FamilyBase + "_pressure_plate" + varient).asItem(), FamilyI)
            .group("wooden_pressure_plate")
            .criterion(hasItem(FamilyHead), conditionsFromItem(FamilyHead))
            .offerTo(exporter);
    
        RecipeProvider
            .createSlabRecipe(RecipeCategory.BUILDING_BLOCKS, BlockFactory.getBlock(FamilyBase + "_slab" + varient).asItem(), FamilyI)
            .group("wooden_slab")
            .criterion(hasItem(FamilyHead), conditionsFromItem(FamilyHead))
            .offerTo(exporter);
    
        RecipeProvider
            .createStairsRecipe(BlockFactory.getBlock(FamilyBase + "_stairs" + varient).asItem(), FamilyI)
            .group("wooden_stairs")
            .criterion(hasItem(FamilyHead), conditionsFromItem(FamilyHead))
            .offerTo(exporter);
    
        RecipeProvider
            .createTransmutationRecipe(BlockFactory.getBlock(FamilyBase + "_button" + varient).asItem(), FamilyI)
            .group("wooden_button")
            .criterion(hasItem(FamilyHead), conditionsFromItem(FamilyHead))
            .offerTo(exporter);
    
        RecipeProvider
            .createDoorRecipe(BlockFactory.getBlock(FamilyBase + "_door" + varient).asItem(), FamilyI)
            .group("wooden_door")
            .criterion(hasItem(FamilyHead), conditionsFromItem(FamilyHead))
            .offerTo(exporter);

        createGlassDoorRecipe(FamilyBase, varient);
    }

    public void generateColorPlank(String color){

        Item result = BlockFactory.getBlock("fungal_planks_" + color).asItem();
        Item MATERIAL = BlockFactory.getBlock("fungal_planks").asItem();
        Item DYE = BlockFactory.getDye(color).asItem();

        ShapedRecipeJsonBuilder.create(RecipeCategory.BUILDING_BLOCKS, result, 8)
        .input('#', MATERIAL)
        .input('D', DYE)
        .pattern("###")
        .pattern("#D#")
        .pattern("###")
        .group("colored_planks")
        .criterion(hasItem(MATERIAL), conditionsFromItem(MATERIAL))
        .criterion(hasItem(DYE), conditionsFromItem(DYE))
        .offerTo(exporter);

        //Dyable Plank System

        ArrayList<Item> cplankGroup = new ArrayList<Item>();
        for (String Icolor : BlockFactory.COLORS){cplankGroup.add(ModBlocks.COLOR_PLANK(Icolor, "planks").asItem());}
    
        ArrayList<Item> plankFinal = new ArrayList<Item>();
        
        for (Item cplank : cplankGroup) {
            if (cplank != result) {
                plankFinal.add(cplank);
            }
        }

        Ingredient cplankI = Ingredient.ofItems(
            plankFinal.get(0),
            plankFinal.get(1),
            plankFinal.get(2),
            plankFinal.get(3),
            plankFinal.get(4),
            plankFinal.get(5),
            plankFinal.get(6),
            plankFinal.get(7),
            plankFinal.get(8),
            plankFinal.get(9),
            plankFinal.get(10),
            plankFinal.get(11),
            plankFinal.get(12),
            plankFinal.get(13),
            plankFinal.get(14)
        );;


        ShapelessRecipeJsonBuilder.create(RecipeCategory.BUILDING_BLOCKS, result, 1)
            .input(cplankI,1)
            .input(DYE, 1)
            .group("colored_planks")
            .criterion(hasItem(MATERIAL), conditionsFromItem(MATERIAL))
            .offerTo(exporter, "dye" + getItemPath(result));   


    }

    public void generateWoolFamily(String FamilyBase, String varient){

        Item wool = BlockFactory.getWoolColor(varient).asItem();

        ShapedRecipeJsonBuilder.create(RecipeCategory.BUILDING_BLOCKS, BlockFactory.getBlock(FamilyBase + "_" + varient))
            .input('#', wool)
            .pattern(" ##")
            .pattern(" ##")
            .pattern("   ")
            .group("textured_wool")
            .criterion(hasItem(wool), conditionsFromItem(wool))
            .offerTo(exporter);
        //Add Carpets
    }

    public static void createGlassDoorRecipe(String FamilyBase, String varient){

        //if (varient == null) {varient = "";}
        //else {varient = "_" + varient;}

        Block PLANK = BlockFactory.getBlock(FamilyBase + "_door" + varient);
        Block DOOR = BlockFactory.getBlock(FamilyBase + "_glass_door" + varient);

        ShapelessRecipeJsonBuilder.create(RecipeCategory.BUILDING_BLOCKS, DOOR, 1)
            .input(PLANK,1)
            .input(Blocks.GLASS_PANE, 1)
            .group("colored_planks")
            .criterion(hasItem(PLANK), conditionsFromItem(PLANK))
            .offerTo(exporter, getItemPath(DOOR));   
    }

    public static void createVanillaGlassDoor(String FamilyBase) {
        Block PLANK = ModBlocks.VANILLA_DOOR(FamilyBase);
        Block DOOR = ModBlocks.MOD_DOOR(FamilyBase + "_glass", null);

        ShapelessRecipeJsonBuilder.create(RecipeCategory.BUILDING_BLOCKS, DOOR, 1)
            .input(PLANK,1)
            .input(Blocks.GLASS_PANE, 1)
            .group("colored_planks")
            .criterion(hasItem(PLANK), conditionsFromItem(PLANK))
            .offerTo(exporter, getItemPath(DOOR)); 
    }

    public static void createVanillaGlassDoorC(String FamilyBase) {
        Block PLANK = ModBlocks.COPPER_DOOR(FamilyBase);
        Block DOOR = ModBlocks.MOD_DOOR(FamilyBase + "_glass", null);

        ShapelessRecipeJsonBuilder.create(RecipeCategory.BUILDING_BLOCKS, DOOR, 1)
            .input(PLANK,1)
            .input(Blocks.GLASS_PANE, 1)
            .group("colored_planks")
            .criterion(hasItem(PLANK), conditionsFromItem(PLANK))
            .offerTo(exporter, getItemPath(DOOR)); 
    }

    public static void createVanillaGlassDoorI() {
        Block PLANK = Blocks.IRON_DOOR;
        Block DOOR = ModBlocks.MOD_DOOR("iron" + "_glass", null);

        ShapelessRecipeJsonBuilder.create(RecipeCategory.BUILDING_BLOCKS, DOOR, 1)
            .input(PLANK,1)
            .input(Blocks.GLASS_PANE, 1)
            .group("colored_planks")
            .criterion(hasItem(PLANK), conditionsFromItem(PLANK))
            .offerTo(exporter, getItemPath(DOOR)); 
    }

    public static void createPlanks(Block Planks, Ingredient Log){
        ShapelessRecipeJsonBuilder.create(RecipeCategory.BUILDING_BLOCKS, Planks, 4)
			.input(Log)
			.group("planks")
			.criterion(hasItem(Blocks.MUSHROOM_STEM), conditionsFromItem(Blocks.MUSHROOM_STEM))
            .criterion(hasItem(Blocks.RED_MUSHROOM_BLOCK), conditionsFromItem(Blocks.RED_MUSHROOM_BLOCK))
            .criterion(hasItem(Blocks.BROWN_MUSHROOM_BLOCK), conditionsFromItem(Blocks.BROWN_MUSHROOM_BLOCK))
			.offerTo(exporter);
    }

    public static void createStoneVarient() {

        //Andesite
        offerStonecuttingRecipe(exporter, RecipeCategory.BUILDING_BLOCKS, BlockFactory.getBlock("polished_andesite_bricks").asItem(), Blocks.ANDESITE);
        offerStonecuttingRecipe(exporter, RecipeCategory.BUILDING_BLOCKS, BlockFactory.getBlock("polished_andesite_bricks").asItem(), Blocks.POLISHED_ANDESITE);

        offerStonecuttingRecipe(exporter, RecipeCategory.BUILDING_BLOCKS, BlockFactory.getBlock("polished_andesite_brick_slab").asItem(), BlockFactory.getBlock("polished_andesite_bricks").asItem(), 2);
        offerStonecuttingRecipe(exporter, RecipeCategory.BUILDING_BLOCKS, BlockFactory.getBlock("polished_andesite_brick_slab").asItem(), Blocks.ANDESITE, 2);
        offerStonecuttingRecipe(exporter, RecipeCategory.BUILDING_BLOCKS, BlockFactory.getBlock("polished_andesite_brick_slab").asItem(), Blocks.POLISHED_ANDESITE, 2);

		offerStonecuttingRecipe(exporter, RecipeCategory.BUILDING_BLOCKS, BlockFactory.getBlock("polished_andesite_brick_stairs").asItem(), BlockFactory.getBlock("polished_andesite_bricks").asItem());
        offerStonecuttingRecipe(exporter, RecipeCategory.BUILDING_BLOCKS, BlockFactory.getBlock("polished_andesite_brick_stairs").asItem(), Blocks.ANDESITE);
        offerStonecuttingRecipe(exporter, RecipeCategory.BUILDING_BLOCKS, BlockFactory.getBlock("polished_andesite_brick_stairs").asItem(), Blocks.POLISHED_ANDESITE);
		
        offerStonecuttingRecipe(exporter, RecipeCategory.DECORATIONS, BlockFactory.getBlock("polished_andesite_brick_wall").asItem(), BlockFactory.getBlock("polished_andesite_bricks").asItem());
        offerStonecuttingRecipe(exporter, RecipeCategory.DECORATIONS, BlockFactory.getBlock("polished_andesite_brick_wall").asItem(), Blocks.ANDESITE);
        offerStonecuttingRecipe(exporter, RecipeCategory.DECORATIONS, BlockFactory.getBlock("polished_andesite_brick_wall").asItem(), Blocks.POLISHED_ANDESITE);

        getWallRecipe(RecipeCategory.DECORATIONS, BlockFactory.getBlock("polished_andesite_brick_wall").asItem(), Ingredient.ofItems(BlockFactory.getBlock("polished_andesite_bricks").asItem()));
        createSlabRecipe(RecipeCategory.BUILDING_BLOCKS, BlockFactory.getBlock("polished_andesite_brick_slab").asItem(), Ingredient.ofItems(BlockFactory.getBlock("polished_andesite_bricks").asItem()));
        createStairsRecipe(BlockFactory.getBlock("polished_andesite_brick_stairs"), Ingredient.ofItems(BlockFactory.getBlock("polished_andesite_bricks").asItem()));



        //Granite
        offerStonecuttingRecipe(exporter, RecipeCategory.BUILDING_BLOCKS, BlockFactory.getBlock("polished_granite_bricks").asItem(), Blocks.GRANITE);
        offerStonecuttingRecipe(exporter, RecipeCategory.BUILDING_BLOCKS, BlockFactory.getBlock("polished_granite_bricks").asItem(), Blocks.POLISHED_GRANITE);

        offerStonecuttingRecipe(exporter, RecipeCategory.BUILDING_BLOCKS, BlockFactory.getBlock("polished_granite_brick_slab").asItem(), BlockFactory.getBlock("polished_granite_bricks").asItem(), 2);
        offerStonecuttingRecipe(exporter, RecipeCategory.BUILDING_BLOCKS, BlockFactory.getBlock("polished_granite_brick_slab").asItem(), Blocks.GRANITE, 2);
        offerStonecuttingRecipe(exporter, RecipeCategory.BUILDING_BLOCKS, BlockFactory.getBlock("polished_granite_brick_slab").asItem(), Blocks.POLISHED_GRANITE, 2);

		offerStonecuttingRecipe(exporter, RecipeCategory.BUILDING_BLOCKS, BlockFactory.getBlock("polished_granite_brick_stairs").asItem(), BlockFactory.getBlock("polished_granite_bricks").asItem());
        offerStonecuttingRecipe(exporter, RecipeCategory.BUILDING_BLOCKS, BlockFactory.getBlock("polished_granite_brick_stairs").asItem(), Blocks.GRANITE);
        offerStonecuttingRecipe(exporter, RecipeCategory.BUILDING_BLOCKS, BlockFactory.getBlock("polished_granite_brick_stairs").asItem(), Blocks.POLISHED_GRANITE);
		
        offerStonecuttingRecipe(exporter, RecipeCategory.DECORATIONS, BlockFactory.getBlock("polished_granite_brick_wall").asItem(), BlockFactory.getBlock("polished_granite_bricks").asItem());
        offerStonecuttingRecipe(exporter, RecipeCategory.DECORATIONS, BlockFactory.getBlock("polished_granite_brick_wall").asItem(), Blocks.GRANITE);
        offerStonecuttingRecipe(exporter, RecipeCategory.DECORATIONS, BlockFactory.getBlock("polished_granite_brick_wall").asItem(), Blocks.POLISHED_GRANITE);

        getWallRecipe(RecipeCategory.DECORATIONS, BlockFactory.getBlock("polished_granite_brick_wall").asItem(), Ingredient.ofItems(BlockFactory.getBlock("polished_granite_bricks").asItem()));
        createSlabRecipe(RecipeCategory.BUILDING_BLOCKS, BlockFactory.getBlock("polished_granite_brick_slab").asItem(), Ingredient.ofItems(BlockFactory.getBlock("polished_granite_bricks").asItem()));
        createStairsRecipe(BlockFactory.getBlock("polished_granite_brick_stairs"), Ingredient.ofItems(BlockFactory.getBlock("polished_granite_bricks").asItem()));



        //Diorite
        offerStonecuttingRecipe(exporter, RecipeCategory.BUILDING_BLOCKS, BlockFactory.getBlock("polished_diorite_bricks").asItem(), Blocks.DIORITE);
        offerStonecuttingRecipe(exporter, RecipeCategory.BUILDING_BLOCKS, BlockFactory.getBlock("polished_diorite_bricks").asItem(), Blocks.POLISHED_DIORITE);

        offerStonecuttingRecipe(exporter, RecipeCategory.BUILDING_BLOCKS, BlockFactory.getBlock("polished_diorite_brick_slab").asItem(), BlockFactory.getBlock("polished_diorite_bricks").asItem(), 2);
        offerStonecuttingRecipe(exporter, RecipeCategory.BUILDING_BLOCKS, BlockFactory.getBlock("polished_diorite_brick_slab").asItem(), Blocks.DIORITE, 2);
        offerStonecuttingRecipe(exporter, RecipeCategory.BUILDING_BLOCKS, BlockFactory.getBlock("polished_diorite_brick_slab").asItem(), Blocks.POLISHED_DIORITE, 2);

		offerStonecuttingRecipe(exporter, RecipeCategory.BUILDING_BLOCKS, BlockFactory.getBlock("polished_diorite_brick_stairs").asItem(), BlockFactory.getBlock("polished_diorite_bricks").asItem());
        offerStonecuttingRecipe(exporter, RecipeCategory.BUILDING_BLOCKS, BlockFactory.getBlock("polished_diorite_brick_stairs").asItem(), Blocks.DIORITE);
        offerStonecuttingRecipe(exporter, RecipeCategory.BUILDING_BLOCKS, BlockFactory.getBlock("polished_diorite_brick_stairs").asItem(), Blocks.POLISHED_DIORITE);
		
        offerStonecuttingRecipe(exporter, RecipeCategory.DECORATIONS, BlockFactory.getBlock("polished_diorite_brick_wall").asItem(), BlockFactory.getBlock("polished_diorite_bricks").asItem());
        offerStonecuttingRecipe(exporter, RecipeCategory.DECORATIONS, BlockFactory.getBlock("polished_diorite_brick_wall").asItem(), Blocks.DIORITE);
        offerStonecuttingRecipe(exporter, RecipeCategory.DECORATIONS, BlockFactory.getBlock("polished_diorite_brick_wall").asItem(), Blocks.POLISHED_DIORITE);

        getWallRecipe(RecipeCategory.DECORATIONS, BlockFactory.getBlock("polished_diorite_brick_wall").asItem(), Ingredient.ofItems(BlockFactory.getBlock("polished_diorite_bricks").asItem()));
        createSlabRecipe(RecipeCategory.BUILDING_BLOCKS, BlockFactory.getBlock("polished_diorite_brick_slab").asItem(), Ingredient.ofItems(BlockFactory.getBlock("polished_diorite_bricks").asItem()));
        createStairsRecipe(BlockFactory.getBlock("polished_diorite_brick_stairs"), Ingredient.ofItems(BlockFactory.getBlock("polished_diorite_bricks").asItem()));

        ShapedRecipeJsonBuilder.create(RecipeCategory.BUILDING_BLOCKS, BlockFactory.getBlock("polished_andesite_bricks"), 4)
			.input('#', Blocks.POLISHED_ANDESITE)
			.pattern("##")
			.pattern("##")
			.criterion(hasItem(Blocks.POLISHED_ANDESITE), conditionsFromItem(Blocks.POLISHED_ANDESITE))
			.offerTo(exporter);
        
        ShapedRecipeJsonBuilder.create(RecipeCategory.BUILDING_BLOCKS, BlockFactory.getBlock("polished_diorite_bricks"), 4)
			.input('#', Blocks.POLISHED_DIORITE)
			.pattern("##")
			.pattern("##")
			.criterion(hasItem(Blocks.POLISHED_DIORITE), conditionsFromItem(Blocks.POLISHED_DIORITE))
			.offerTo(exporter);

        ShapedRecipeJsonBuilder.create(RecipeCategory.BUILDING_BLOCKS, BlockFactory.getBlock("polished_granite_bricks"), 4)
			.input('#', Blocks.POLISHED_GRANITE)
			.pattern("##")
			.pattern("##")
			.criterion(hasItem(Blocks.POLISHED_GRANITE), conditionsFromItem(Blocks.POLISHED_GRANITE))
			.offerTo(exporter);


    }



























    ////////////////////////////////////////////


    //Recipe Creator for Long Sword




    ///////////////////


    
    //Recipe Create for Wood Group
    @Deprecated
    public static void createWoodGroup(String baseItemName, String endTag){
        Ingredient baseItemI = Ingredient.ofItems(BlockFactory.getBlock(baseItemName + "_planks" + endTag).asItem());
        Item baseItem = (BlockFactory.getBlock(baseItemName + "_planks" + endTag).asItem());

        RecipeProvider.createTrapdoorRecipe(BlockFactory.getBlock(baseItemName + "_trapdoor" + endTag).asItem(), baseItemI)
        .group("wooden_trapdoor")
        .criterion(hasItem(baseItem), conditionsFromItem(baseItem))
        .offerTo(exporter);

        RecipeProvider.createFenceRecipe(BlockFactory.getBlock(baseItemName + "_fence" + endTag).asItem(), baseItemI)
        .group("wooden_fence")
        .criterion(hasItem(baseItem), conditionsFromItem(baseItem))
        .offerTo(exporter);

        RecipeProvider.createFenceGateRecipe(BlockFactory.getBlock(baseItemName + "_fence_gate" + endTag).asItem(), baseItemI)
        .group("wooden_fence_gate")
        .criterion(hasItem(baseItem), conditionsFromItem(baseItem))
        .offerTo(exporter);

        RecipeProvider.createPressurePlateRecipe(RecipeCategory.BUILDING_BLOCKS, BlockFactory.getBlock(baseItemName + "_pressure_plate" + endTag).asItem(), baseItemI)
        .group("wooden_pressure_plate")
        .criterion(hasItem(baseItem), conditionsFromItem(baseItem))
        .offerTo(exporter);

        RecipeProvider.createSlabRecipe(RecipeCategory.BUILDING_BLOCKS, BlockFactory.getBlock(baseItemName + "_slab" + endTag).asItem(), baseItemI)
        .group("wooden_slab")
        .criterion(hasItem(baseItem), conditionsFromItem(baseItem))
        .offerTo(exporter);

        RecipeProvider.createStairsRecipe(BlockFactory.getBlock(baseItemName + "_stairs" + endTag).asItem(), baseItemI)
        .group("wooden_stairs")
        .criterion(hasItem(baseItem), conditionsFromItem(baseItem))
        .offerTo(exporter);

        RecipeProvider.createTransmutationRecipe(BlockFactory.getBlock(baseItemName + "_button" + endTag).asItem(), baseItemI)
        .group("wooden_button")
        .criterion(hasItem(baseItem), conditionsFromItem(baseItem))
        .offerTo(exporter);

        RecipeProvider.createDoorRecipe(BlockFactory.getBlock(baseItemName + "_door" + endTag).asItem(), baseItemI)
        .group("wooden_door")
        .criterion(hasItem(baseItem), conditionsFromItem(baseItem))
        .offerTo(exporter);
    }

    //Recipe Create for Color Planks
    @Deprecated
    public static void createColorPlanks(Item dye, ItemConvertible output, String color) {

		ShapedRecipeJsonBuilder.create(RecipeCategory.BUILDING_BLOCKS, output, 8)
        .input('#', BlockFactory.getBlock("fungal_planks").asItem())
        .input('D', dye)
        .pattern("###")
        .pattern("#D#")
        .pattern("###")
        .group("colored_planks")
        .criterion(hasItem(BlockFactory.getBlock("fungal_planks").asItem()), conditionsFromItem(BlockFactory.getBlock("fungal_planks").asItem()))
        .criterion(hasItem(dye), conditionsFromItem(dye))
        .offerTo(exporter);
        
        createWoodGroup("fungal", "_" + color);
	}

    //Recipe Create for Modded Weapons - Wood & Stone
    @Deprecated
    public static void createModdedWeapon(Item Material, String baseMat, TagKey<Item> matTag) {

        createLongSword(Material, WeaponFactory.getItem(baseMat + "_long_sword"), matTag);
        createDagger(Material, WeaponFactory.getItem(baseMat + "_dagger"), matTag);
        createHammer(Material, WeaponFactory.getItem(baseMat + "_hammer"), matTag);

    }

    //Recipe Create for Modded Weapons - Gold, Iron & Diamond
    @Deprecated
    public static void createModdedWeapon(Item Material, String baseMat) {

        createLongSword(Material, WeaponFactory.getItem(baseMat + "_long_sword"));
        createDagger(Material, WeaponFactory.getItem(baseMat + "_dagger"));
        createHammer(Material, WeaponFactory.getItem(baseMat + "_hammer"));

        boolean Enabled = false;

        if ("iron" == baseMat && Enabled){
            generateMeltIron(Ingredient.ofItems(
                WeaponFactory.getItem(baseMat + "_long_sword"),
                WeaponFactory.getItem(baseMat + "_dagger"),
                WeaponFactory.getItem(baseMat + "_hammer")
            ));   
        } 
        else if ("golden" == baseMat && Enabled){
            generateMeltGold(Ingredient.ofItems(
                WeaponFactory.getItem(baseMat + "_long_sword"),
                WeaponFactory.getItem(baseMat + "_dagger"),
                WeaponFactory.getItem(baseMat + "_hammer")
            )); 
        }

    }

    //Recipe Melt to Gold Nuggets
    @Deprecated
    public static void generateMeltGold(Ingredient SmeltItems) {
        CookingRecipeJsonBuilder.createSmelting(
            SmeltItems,
            RecipeCategory.MISC,
			Items.GOLD_NUGGET,
			0.1F,
			200
        )
        .criterion(hasItem(WeaponFactory.getItem(Items.GOLD_INGOT + "_long_sword")), conditionsFromItem(WeaponFactory.getItem(Items.GOLD_INGOT + "_long_sword")))
        .criterion(hasItem(WeaponFactory.getItem(Items.GOLD_INGOT + "_dagger")), conditionsFromItem(WeaponFactory.getItem(Items.GOLD_INGOT + "_dagger")))
        .criterion(hasItem(WeaponFactory.getItem(Items.GOLD_INGOT + "_hammer")), conditionsFromItem(WeaponFactory.getItem(Items.GOLD_INGOT + "_hammer")))
		.offerTo(exporter, getSmeltingItemPath(Items.GOLD_NUGGET));
    }

    //Recipe Melt to Iron Nuggets
    @Deprecated
    public static void generateMeltIron(Ingredient SmeltItems) {
        CookingRecipeJsonBuilder.createSmelting(
            SmeltItems,
            RecipeCategory.MISC,
			Items.IRON_NUGGET,
			0.1F,
			200
        )
        .criterion(hasItem(WeaponFactory.getItem(Items.IRON_INGOT + "_long_sword")), conditionsFromItem(WeaponFactory.getItem(Items.IRON_INGOT + "_long_sword")))
        .criterion(hasItem(WeaponFactory.getItem(Items.IRON_INGOT + "_dagger")), conditionsFromItem(WeaponFactory.getItem(Items.IRON_INGOT + "_dagger")))
        .criterion(hasItem(WeaponFactory.getItem(Items.IRON_INGOT + "_hammer")), conditionsFromItem(WeaponFactory.getItem(Items.IRON_INGOT + "_hammer")))
		.offerTo(exporter, getSmeltingItemPath(Items.IRON_NUGGET));
    }

}
