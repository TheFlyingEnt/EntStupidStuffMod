package net.ent.entstupidstuff;

import net.ent.entstupidstuff.block.BlockFactory;
import net.ent.entstupidstuff.enchant.EnchantmentFactory;
import net.ent.entstupidstuff.event.WeaponEvent;
import net.ent.entstupidstuff.item.WeaponFactory;
import net.ent.entstupidstuff.registry.EntityFactory;
import net.ent.entstupidstuff.registry.SpawningFactory;
import net.ent.entstupidstuff.item.ModFood;
import net.ent.entstupidstuff.item.ModSpawnEgg;
import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EntStupidStuff implements ModInitializer {

	public static final String MOD_ID = "entstupidstuff";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	public static final Identifier id(String path) {
        return Identifier.of("entstupidstuff", path);
    }


	@Override
	public void onInitialize() {
		LOGGER.info("Mod Initializing");

		WeaponEvent.onInitialize();
		WeaponFactory.onInitialize();
		EntityFactory.onInitialize();
		ModSpawnEgg.onInitialize();
		SpawningFactory.onInitialize();
		//BlockFactory.onInitialize();
		BlockFactory.onInitialize();
		EnchantmentFactory.onInitialize();
		ModFood.onInitialize();

		//AttackCallbackAll.EVENT.register(WeaponEvent::onEntityAttack);

		
	}
}