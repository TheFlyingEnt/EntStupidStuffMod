package net.ent.entstupidstuff.api;

//ChatGPTed

import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;

public class TwoHandTrait {

    public static boolean isUsingTwoHands(PlayerEntity player) {
        return !player.getOffHandStack().isEmpty();
    }

    public static void applyMiningFatigue(PlayerEntity player) {
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.MINING_FATIGUE, 100, 1));
    }
}

