package net.ent.entstupidstuff.item.itemType;

import java.util.List;

import net.ent.entstupidstuff.EntStupidStuff;

import net.ent.entstupidstuff.api.TwoHandTrait;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;


public class LongSwordItem extends SwordItem {



    public LongSwordItem(ToolMaterial toolMaterial, Settings settings) {
        super(toolMaterial, settings);

    }

    public static final Identifier ATTK_BMOD_ID = EntStupidStuff.id("double_handed_bonus");

    // For 1.20.5+
    @Override
    public void appendTooltip(ItemStack itemStack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.translatable("item.entstupidstuff.double_hand.tooltip"));
    }


    

    @Override
    public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        if (attacker instanceof PlayerEntity) {
            PlayerEntity player = (PlayerEntity) attacker;
            if (TwoHandTrait.isUsingTwoHands(player)) {
                TwoHandTrait.applyMiningFatigue(player);
            }
        }
        return super.postHit(stack, target, attacker);
    }

}
