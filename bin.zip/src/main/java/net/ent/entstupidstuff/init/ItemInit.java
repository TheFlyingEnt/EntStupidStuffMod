package net.ent.entstupidstuff.init;

import java.util.LinkedHashMap;
import java.util.Map;

import net.ent.entstupidstuff.item.itemType.LongSwordItem;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.component.type.AttributeModifierSlot;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.item.ToolMaterials;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class ItemInit {


    //Var ArrayList/List Map Containing All Items
    public static final Map<Identifier, Item> ItemList = new LinkedHashMap<>();

    //Creating Var Item Group with will Contain all Vanilla Weapon Types:
    public static final RegistryKey<ItemGroup> ENTSTUPIDSTUFF_COMBAT_GROUP = RegistryKey.of(RegistryKeys.ITEM_GROUP, Identifier.of("entstupidstuff", "combat_group"));


    /*
     *  Creating Items: Long Swords
     */

     float LS_AttackS = 0;

     public static final LongSwordItem WOOD_LONG_SWORD_ITEM = registerItems("wooden_long_sword",
        new LongSwordItem(ToolMaterials.WOOD,
            new Item.Settings()
            .attributeModifiers(SwordItem
            .createAttributeModifiers(ToolMaterials.WOOD, 0, 7) //Replace with LSAttackS
            .with(EntityAttributes.PLAYER_ENTITY_INTERACTION_RANGE,
            new EntityAttributeModifier(LongSwordItem.ATTK_BMOD_ID, 0.8f, EntityAttributeModifier.Operation.ADD_VALUE), AttributeModifierSlot.MAINHAND))));


    //Weapon Type: Long Swords










 
   
    
    public static <I extends Item> I registerItems(String name, I item) {
        ItemList.put(Identifier.of("entstupidstuff", name), item);
        return item;

    }


    public static void onInitialize() {

        //Registering: Combat Tab (Item Group)
        Registry.register(Registries.ITEM_GROUP, ENTSTUPIDSTUFF_COMBAT_GROUP, FabricItemGroup.builder()
        .icon(() -> new ItemStack(WOOD_LONG_SWORD_ITEM))
        .displayName(Text.translatable("item.entstupidstuff.item_group"))
        .build());

        //Registering: Combat Items
        for (Identifier id : ItemList.keySet()) {
            Registry.register(Registries.ITEM, id, ItemList.get(id));
            ItemGroupEvents.modifyEntriesEvent(ENTSTUPIDSTUFF_COMBAT_GROUP).register(entries -> entries.add(ItemList.get(id)));
        }

    }
}
