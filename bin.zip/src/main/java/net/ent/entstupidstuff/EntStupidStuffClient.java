package net.ent.entstupidstuff;

import net.fabricmc.api.ClientModInitializer;

public class EntStupidStuffClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {

    }
}
