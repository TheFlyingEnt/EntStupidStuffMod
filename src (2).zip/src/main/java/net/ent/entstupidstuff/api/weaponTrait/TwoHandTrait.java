package net.ent.entstupidstuff.api.weaponTrait;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;

public class TwoHandTrait {

    public static boolean isUsingTwoHands(PlayerEntity player) {
        return !player.getOffHandStack().isEmpty();
    }

    public static float applyDamageReduction(LivingEntity attacker, LivingEntity target, float baseDamage) {
        double damageMultiplier = 0.25; // 75% damage reduction
        float adjustedDamage = baseDamage * (float) damageMultiplier;
        //target.damage(attacker.getDamageSources().playerAttack((PlayerEntity) attacker), adjustedDamage);
        return adjustedDamage;
    }

    public static void applyMiningFatigue(PlayerEntity player) {
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.MINING_FATIGUE, 20, 4));
    }


}
