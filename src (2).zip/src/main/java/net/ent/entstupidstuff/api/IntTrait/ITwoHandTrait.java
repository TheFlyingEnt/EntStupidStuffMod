package net.ent.entstupidstuff.api.IntTrait;

public interface ITwoHandTrait {
    // Marker interface, empty marker interface
}
