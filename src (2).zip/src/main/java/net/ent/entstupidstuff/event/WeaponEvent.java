package net.ent.entstupidstuff.event;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.ent.entstupidstuff.api.weaponTrait.TwoHandTrait;
import net.ent.entstupidstuff.api.weaponTrait.BluntTrait;
import net.ent.entstupidstuff.api.IntTrait.IBluntTrait;
import net.ent.entstupidstuff.api.IntTrait.ITwoHandTrait;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;

public class WeaponEvent {

    
    public static void onInitialize() {
        // Register the AttackEntityCallback event
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (entity instanceof LivingEntity && player instanceof PlayerEntity) {
                PlayerEntity playerEntity = (PlayerEntity) player;
                LivingEntity target = (LivingEntity) entity;
                ItemStack mainHandStack = playerEntity.getMainHandStack();
                Item mainHandItem = mainHandStack.getItem();

                //Pre-Trait Damage:
                float baseDamage = (float) playerEntity.getAttributeValue(net.minecraft.entity.attribute.EntityAttributes.GENERIC_ATTACK_DAMAGE);

                if (mainHandItem instanceof ITwoHandTrait && TwoHandTrait.isUsingTwoHands(playerEntity)) {
                    baseDamage = TwoHandTrait.applyDamageReduction(playerEntity, target, baseDamage);
                    TwoHandTrait.applyMiningFatigue(playerEntity);
                }
                
                if (mainHandItem instanceof IBluntTrait){
                    BluntTrait.applyBluntEffect(entity);
                    BluntTrait.applyShock(playerEntity);
                }

                target.damage(playerEntity.getDamageSources().playerAttack((PlayerEntity) playerEntity), baseDamage);
                

                // Cancel the attack cooldown and return success
                playerEntity.resetLastAttackedTicks();

                return ActionResult.SUCCESS;
            }
            return ActionResult.PASS;
        });
    }

}
