package net.ent.entstupidstuff.item.itemType;

import java.util.List;

import net.ent.entstupidstuff.api.IntTrait.ITwoHandTrait;
import net.ent.entstupidstuff.item.WeaponItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ToolMaterial;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.text.Text;




public class LongSwordItem extends WeaponItem implements ITwoHandTrait{

    public LongSwordItem(ToolMaterial toolMaterial, Settings settings) {
        super(toolMaterial, settings.attributeModifiers(WeaponItem.createAttributeModifiers(toolMaterial, (3.5)  + toolMaterial.getAttackDamage(), -2.6f, 1, 1, 0)));
        
        //material, baseAttackDamage (Added), attackSpeed (Added), toolReach (Added), attackSweep (Added)

    }

    // For 1.20.5+ Adding TwoHanded ToolTip
    @Override
    public void appendTooltip(ItemStack itemStack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.translatable("item.entstupidstuff.double_hand.tooltip"));
    }

    
}
