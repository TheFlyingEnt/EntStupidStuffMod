package net.ent.entstupidstuff;

import net.ent.entstupidstuff.init.WeaponFactory;
import net.ent.entstupidstuff.event.WeaponEvent;
import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EntStupidStuff implements ModInitializer {

	public static final String MOD_ID = "entstupidstuff";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	public static final Identifier id(String path) {
        return Identifier.of("entstupidstuff", path);
    }


	@Override
	public  void onInitialize() {
		LOGGER.info("Mod Initializing");
		
		WeaponFactory.onInitialize();
		WeaponEvent.onInitialize();




	}
}