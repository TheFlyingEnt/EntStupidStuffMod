package net.ent.entstupidstuff.init;

import java.util.LinkedHashMap;
import java.util.Map;

import net.ent.entstupidstuff.item.itemType.DaggerItem;
import net.ent.entstupidstuff.item.itemType.HammerItem;
import net.ent.entstupidstuff.item.itemType.LongSwordItem;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ToolMaterials;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class WeaponFactory {

    public static final Map<Identifier, Item> ItemList = new LinkedHashMap<>(); //Mapping For Items

    public static final RegistryKey<ItemGroup> ENTSTUPIDSTUFF_COMBAT_GROUP = RegistryKey.of(RegistryKeys.ITEM_GROUP, Identifier.of("entstupidstuff", "combat_group")); //Registering Item Group


    //Dagger Registery

    String[] materialArray = new String[]{"wood", "diamond"};

    //Complete Auto Adding System - Priority LOW
    public static final LongSwordItem DIAMOND_LONG_SWORD_ITEM = registerItems("diamond_long_sword", new LongSwordItem(ToolMaterials.DIAMOND, new Item.Settings()));

    public static final void Reg() {
        registerItems("wooden_dagger", new DaggerItem(ToolMaterials.WOOD, new Item.Settings()));
        registerItems("stone_dagger", new DaggerItem(ToolMaterials.STONE, new Item.Settings()));
        registerItems("gold_dagger", new DaggerItem(ToolMaterials.GOLD, new Item.Settings()));
        registerItems("iron_dagger", new DaggerItem(ToolMaterials.IRON, new Item.Settings()));
        registerItems("diamond_dagger", new DaggerItem(ToolMaterials.DIAMOND, new Item.Settings()));
        registerItems("netherite_dagger", new DaggerItem(ToolMaterials.NETHERITE, new Item.Settings().fireproof()));

        registerItems("wooden_hammer", new HammerItem(ToolMaterials.WOOD, new Item.Settings()));
        registerItems("stone_hammer", new HammerItem(ToolMaterials.STONE, new Item.Settings()));
        registerItems("gold_hammer", new HammerItem(ToolMaterials.GOLD, new Item.Settings()));
        registerItems("iron_hammer", new HammerItem(ToolMaterials.IRON, new Item.Settings()));
        registerItems("diamond_hammer", new HammerItem(ToolMaterials.DIAMOND, new Item.Settings()));
        registerItems("netherite_hammer", new HammerItem(ToolMaterials.NETHERITE, new Item.Settings().fireproof()));

        registerItems("wooden_long_sword", new LongSwordItem(ToolMaterials.WOOD, new Item.Settings()));
        registerItems("stone_long_sword", new LongSwordItem(ToolMaterials.STONE, new Item.Settings()));
        registerItems("gold_long_sword", new LongSwordItem(ToolMaterials.GOLD, new Item.Settings()));
        registerItems("iron_long_sword", new LongSwordItem(ToolMaterials.IRON, new Item.Settings()));
        //registerItems("diamond_long_sword", new LongSwordItem(ToolMaterials.DIAMOND, new Item.Settings()));
        registerItems("netherite_long_sword", new LongSwordItem(ToolMaterials.NETHERITE, new Item.Settings().fireproof()));
    }

    public static <I extends Item> I registerItems(String name, I item) {
        ItemList.put(Identifier.of("entstupidstuff", name), item);
        return item;

    }

    public static void onInitialize() {

        WeaponFactory.Reg();

        //Registering: Combat Tab (Item Group)
        Registry.register(Registries.ITEM_GROUP, ENTSTUPIDSTUFF_COMBAT_GROUP, FabricItemGroup.builder()
        .icon(() -> new ItemStack(DIAMOND_LONG_SWORD_ITEM))
        .displayName(Text.translatable("item.entstupidstuff.item_group"))
        .build());

        //Registering: Combat Items
        for (Identifier id : ItemList.keySet()) {
            Registry.register(Registries.ITEM, id, ItemList.get(id));
            ItemGroupEvents.modifyEntriesEvent(ENTSTUPIDSTUFF_COMBAT_GROUP).register(entries -> entries.add(ItemList.get(id)));
        }
    }
}
