package net.ent.entstupidstuff.item.itemType;

import java.util.List;

import net.ent.entstupidstuff.api.IntTrait.ITwoHandTrait;
import net.ent.entstupidstuff.item.WeaponItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.text.Text;


public class DaggerItem extends SwordItem implements ITwoHandTrait{

    /***
     * @param toolMaterial
     * @param settings
     * @param - Material
     * @param - # + toolMaterial Damage + 1
     * @param - Default Speed (4) - #
     * @param - AttackSpeed
    */

    public DaggerItem(ToolMaterial toolMaterial, Settings settings) {
        super(toolMaterial, settings.attributeModifiers(WeaponItem.createAttributeModifiers(toolMaterial, (3.5)  + toolMaterial.getAttackDamage(), -2.6f, 1, 1, 0)));
    }


    /*@Override
    public void inventoryTick(ItemStack stack, World world, Entity entity, int slot, boolean selected ) {
        System.out.println("Dagger Check");
        TwoHandTrait.weaponCheck(stack, world, entity, slot, selected, this.getMaterial(), (float)(3.5)  + this.getMaterial().getAttackDamage());

    }*/

    // For 1.20.5+ Adding TwoHanded ToolTip
    @Override
    public void appendTooltip(ItemStack itemStack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.translatable("item.entstupidstuff.double_hand.tooltip"));
    }

    /*@Override
	public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {

        

		return super.postHit(stack, target, attacker);
	}*/


}
