package net.ent.entstupidstuff.api.weaponTrait;

import net.ent.entstupidstuff.api.IntTrait.ITrait;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

public class BleedingTrait implements ITrait {
    public static float /*void*/ applyBleedingEffect(PlayerEntity attacker, LivingEntity target, float baseDamage) {
        float targetHealth = target.getHealth();
        float targetMaxHealth = target.getMaxHealth();
        float damageMultiplier = targetHealth < 0.25 * targetMaxHealth ? 2.0f : 1.0f;
        return damageMultiplier;
        //target.damage(attacker.getDamageSources().playerAttack(attacker), baseDamage * damageMultiplier);
    }
}

