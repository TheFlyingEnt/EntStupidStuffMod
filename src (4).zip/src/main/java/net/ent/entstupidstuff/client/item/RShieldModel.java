package net.ent.entstupidstuff.client.item;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.model.Model;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

@Environment(EnvType.CLIENT) //For Client Side
public abstract class RShieldModel extends Model {

    public RShieldModel(java.util.function.Function<Identifier, RenderLayer> function) {
        super(function); //This is creating Model based on #Model with Layer Suport
    }

    public abstract ModelPart basePlate(); //This is Replicating Mojangs Shield Class
    public abstract ModelPart baseHandle(); //This is Replicating Mojangs Shield Class

    public abstract void renderToBuffer(MatrixStack matrices, VertexConsumer vertexconsumer, int i, int j, float f, float g, float h, float k);
}
