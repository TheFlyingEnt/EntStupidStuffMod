package net.ent.entstupidstuff.item.itemType;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.item.ShieldItem;
import net.minecraft.resource.*;

public class RShield extends ShieldItem{

    public RShield(Settings settings) {
            super(settings);
    }

   /* @Environment(EnvType.CLIENT) //Client Rendering
    public void RegModel() {
        this.register(this, new ResourceLocation("blocking"), (stack, level, entity, i) ->
				entity != null && entity.isUsingItem() && entity.getUseItem() == stack ? 1.0F : 0.0F);
    } */

}
