package net.ent.entstupidstuff.init;

import net.ent.entstupidstuff.item.itemType.RShield;
import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.render.entity.model.ShieldEntityModel;
import net.minecraft.client.texture.SpriteAtlasTexture;
import net.minecraft.client.util.SpriteIdentifier;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;

public class ShieldFactory {

    public static final EntityModelLayer diamond_banner_shield_model_layer = new EntityModelLayer(Identifier.of("entstupidstuff", "shield_diamond"),"main");

    public static ShieldEntityModel modelNetheriteShield;

    public static final EntityModelLayer DIAMOND_SHIELD_MODEL_LAYER = new EntityModelLayer(Identifier.of("examplemod", "diamond_shield"),"main");


    @SuppressWarnings("deprecation")
    public static final SpriteIdentifier DIAMOND_BANNER_SHIELD_BASE = new SpriteIdentifier(SpriteAtlasTexture.BLOCK_ATLAS_TEXTURE, Identifier.of("entstupidstuff", "entity/diamond_shield_base"));
	@SuppressWarnings("deprecation")
    public static final SpriteIdentifier DIAMOND_BANNER_SHIELD_BASE_NO_PATTERN = new SpriteIdentifier(SpriteAtlasTexture.BLOCK_ATLAS_TEXTURE, Identifier.of("entstupidstuff", "entity/diamond_shield_nopattern"));

    public static final Item DIAMOND_BANNER_SHIELD = new RShield(new Item.Settings().maxDamage(2500)); // FabricBannerShieldItem(settings.maxDamage(durability), cooldownTicks, enchantability, repairItems)


    public static void onInitialize() {

        Registry.register(Registries.ITEM, Identifier.of("entstupidstuff", "diamond_shield"), DIAMOND_BANNER_SHIELD);

        EntityModelLayerRegistry.registerModelLayer(DIAMOND_SHIELD_MODEL_LAYER, ShieldEntityModel::getTexturedModelData);






        /*ShieldSetModelCallback.EVENT.register((loader) -> {
	        modelNetheriteShield = new ShieldEntityModel(loader.getModelPart(diamond_banner_shield_model_layer));
	        return ActionResult.PASS;
	    });

        BuiltinItemRendererRegistry.INSTANCE.register(ShieldFactory.DIAMOND_BANNER_SHIELD, (stack, mode, matrices, vertexConsumers, light, overlay) -> {
		renderBanner(stack, matrices, vertexConsumers, light, overlay, modelNetheriteShield, DIAMOND_BANNER_SHIELD_BASE, DIAMOND_BANNER_SHIELD_BASE_NO_PATTERN);
                //The first five parameters are taken from the method, while the last 3 you provide yourself. You will provide the model, and then your 2 sprite identifiers in the order of SHIELD_NAME_BASE and then SHIELD_NAME_BASE_NOPATTERN.
	    });*/

    }

    

}
