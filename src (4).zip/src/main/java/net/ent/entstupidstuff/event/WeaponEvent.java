package net.ent.entstupidstuff.event;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.ent.entstupidstuff.api.weaponTrait.TwoHandTrait;
import net.ent.entstupidstuff.api.weaponTrait.BleedingTrait;
import net.ent.entstupidstuff.api.weaponTrait.BluntTrait;
import net.ent.entstupidstuff.api.IntTrait.IBleedingTrait;
import net.ent.entstupidstuff.api.IntTrait.IBluntTrait;
import net.ent.entstupidstuff.api.IntTrait.ITwoHandTrait;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;


public class WeaponEvent {

    
    public static void onInitialize() {
        // Register the AttackEntityCallback event
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {

            if (entity instanceof LivingEntity && player instanceof PlayerEntity) {
                //System.out.println(player.getDisplayName() + " attack Detected");

                ItemStack mainHandStack = player.getMainHandStack();
                Item mainHandItem = mainHandStack.getItem(); //Getting Item

                System.out.println(player.getCustomName() + " attack Detected with " + mainHandItem.getName());

                //Implementation of Legacy Code

                float baseDamage = (float) player.getAttributeValue(net.minecraft.entity.attribute.EntityAttributes.GENERIC_ATTACK_DAMAGE);

                if (mainHandItem instanceof ITwoHandTrait) {

                    System.out.println("Applying Effect: TwoHand");

                    if (TwoHandTrait.isUsingTwoHands(player)) {
                        System.out.println("     - isUsingTwoHand = True");
                        TwoHandTrait.applyDamageReductionOG(player, true, baseDamage);
                        TwoHandTrait.applyMiningFatigue(player);
                    }
                    else {
                        System.out.println("     - isUsingTwoHand = False");
                        TwoHandTrait.applyDamageReductionOG(player, false, baseDamage);
                        TwoHandTrait.applyMiningFatigue(player);
                    }
                }

                if (mainHandItem instanceof IBluntTrait) {
                    System.out.println("Applying Effect: Blunt");
                    BluntTrait.applyBluntEffect(player, (LivingEntity) entity); //TODO: Implement Error Correction
                }

                if (mainHandItem instanceof IBleedingTrait) {
                    System.out.println("Applying Effect: Blunt");
                    BleedingTrait.applyBleedingEffect(player, (LivingEntity) entity, baseDamage); //TODO: Implement Error Correction
                }

                System.out.println(" ");


                return ActionResult.PASS;

            }















            /*if (entity instanceof LivingEntity && player instanceof PlayerEntity) {
                PlayerEntity playerEntity = (PlayerEntity) player;
                LivingEntity target = (LivingEntity) entity;
                ItemStack mainHandStack = playerEntity.getMainHandStack();
                Item mainHandItem = mainHandStack.getItem();

                //Pre-Trait Damage:
                float baseDamage = (float) playerEntity.getAttributeValue(net.minecraft.entity.attribute.EntityAttributes.GENERIC_ATTACK_DAMAGE);
                System.out.println(baseDamage);

                // TODO: Fix the Sweep Damage as All Weapon (Inlcuding Vanilla) does not have it.

                if (mainHandItem instanceof ITwoHandTrait && TwoHandTrait.isUsingTwoHands(playerEntity)) {
                    baseDamage = TwoHandTrait.applyDamageReduction(playerEntity, target, baseDamage);
                    TwoHandTrait.applyMiningFatigue(playerEntity);
                }
                
                if (mainHandItem instanceof IBluntTrait){
                    BluntTrait.applyBluntEffect(playerEntity, target);
                    world.addParticle(ParticleTypes.CRIT, target.getX(), target.getY(), target.getZ(), 0.0D, 0.0D, 0.0D);
                }

                if (mainHandItem instanceof IBleedingTrait) {
                    baseDamage = BleedingTrait.applyBleedingEffect(player, target, baseDamage);
                }

                target.damage(playerEntity.getDamageSources().playerAttack((PlayerEntity) playerEntity), baseDamage);

                // Cancel the attack cooldown and return success
                playerEntity.resetLastAttackedTicks();

                return ActionResult.PASS;*/
            
            return ActionResult.PASS;
        });
    }
}
