package net.ent.entstupidstuff;

import net.fabricmc.api.ClientModInitializer;

public class EntStupidStuffClient implements ClientModInitializer {

    //private static final MinecraftClient client = MinecraftClient.getInstance();

    @Override
    public void onInitializeClient() {

        //WeaponEvent.onInitialize();

        // Register a client tick event to check for charging attack
        /*ClientTickEvents.END_CLIENT_TICK.register(client -> {
            PlayerEntity player = client.player;
            if (player != null) {
                ItemStack mainHandStack = player.getMainHandStack();
                if (mainHandStack.getItem() instanceof LongSwordItem && player.isUsingItem() && player.getActiveHand() == Hand.MAIN_HAND) {
                    // Render the vanilla attack indicator
                    player.getItemCooldownManager().set(player.getMainHandStack().getItem(), 20); // Set cooldown for 1 second (20 ticks)
                }
            }
        });*/
    }
}
